CREATE TABLE admi (
    Id_admi INT(15) AUTO_INCREMENT,
    Nombre VARCHAR(25),
    Foto LONGBLOB,
    Correo VARCHAR(50),
    Contrasena VARCHAR(100),
    Fecha_nacimiento DATE,
    Genero VARCHAR(15),
    PRIMARY KEY(Id_admi)
);

CREATE TABLE administradores_datos (
    Id_datos INT(15) AUTO_INCREMENT,
    Fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Token VARCHAR(50),
    Codigo INT(11),
    Fecha_token TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Id_administrador INT(15),
    PRIMARY KEY(Id_datos),
    FOREIGN KEY(Id_administrador) REFERENCES admi(Id_admi) ON DELETE CASCADE ON UPDATE CASCADE
);