CREATE TABLE editores (
    Id_editor INT(15) AUTO_INCREMENT,
    Nombre VARCHAR(25),
    Foto LONGBLOB,
    Fecha_nacimiento DATE,
    Genero VARCHAR(15),
    Correo VARCHAR(50),
    Contrasena VARCHAR(100),
    PRIMARY KEY(Id_editor)
);

CREATE TABLE editores_datos (
    Id_datos INT(15) AUTO_INCREMENT,
    Fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Token VARCHAR(50),
    Codigo INT(11),
    Fecha_token TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Id_editor INT(15),
    PRIMARY KEY(Id_datos),
    FOREIGN KEY(Id_editor) REFERENCES editores(Id_editor) ON DELETE CASCADE ON UPDATE CASCADE
);