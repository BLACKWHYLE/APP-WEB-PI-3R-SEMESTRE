CREATE TABLE publicaciones (
    Id_publicacion INT(15) AUTO_INCREMENT,
    Contenido TEXT,
    Imagen LONGBLOB,
    Id_editor INT(15),
    PRIMARY KEY(Id_publicacion),
    FOREIGN KEY(Id_editor) REFERENCES editores(Id_editor) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE publicaciones_datos (
    Id_datos INT(15) AUTO_INCREMENT,
    Estatus VARCHAR(20),
    Fecha_publicacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Fecha_cambio_estaths TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Comentarios_estatus VARCHAR(150),
    Id_administrador_aprobador INT(15),
    PRIMARY KEY(Id_datos),
    FOREIGN KEY(Id_administrador_aprobador) REFERENCES admi(Id_admi) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE comentarios (
    Id_comentario INT(15) AUTO_INCREMENT,
    Texto VARCHAR(255),
    Id_usuario INT(15),
    Id_publicacion INT(15),
    Fecha_comentario TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(Id_comentario),
    FOREIGN KEY(Id_usuario) REFERENCES usuarios(Id_usuario) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY(Id_publicacion) REFERENCES publicaciones(Id_publicacion) ON DELETE CASCADE ON UPDATE CASCADE
);