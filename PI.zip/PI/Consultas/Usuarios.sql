CREATE TABLE usuarios (
  Id_usuario INT(15) AUTO_INCREMENT,
  Nombre VARCHAR(25),
  Foto LONGBLOB,
  Fecha_Nacimiento DATE,
  Genero VARCHAR(15),
  Correo VARCHAR(50),
  Contrasena VARCHAR(100),
  PRIMARY KEY(Id_usuario)
);

CREATE TABLE usuarios_datos_registro (
  Id_datos INT(15) AUTO_INCREMENT,
  Fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  Token VARCHAR(50),
  Codigo INT(11),
  Fecha_token TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  Id_usuario INT(15),
  PRIMARY KEY(Id_datos),
  FOREIGN KEY(Id_usuario) REFERENCES usuarios(Id_usuario) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Insertar datos en la tabla usuarios
INSERT INTO usuarios (Nombre, Fecha_Nacimiento, Genero, Correo, Contrasena)
VALUES ('Juan', '2020-01-01', 'Masculino', 'juan@example.com', 'contrasena123');

-- Obtener el ID del usuario recién insertado
SET @id_usuario = LAST_INSERT_ID();

-- Insertar datos en la tabla usuarios_datos_registro
INSERT INTO usuarios_datos_registro (Token, Codigo, Id_usuario)
VALUES ('abcd1234', 1234, @id_usuario);

UPDATE usuarios_datos_registro
SET Token = 'nuevo_token',
    Codigo = 5678,
    Fecha_token = CURRENT_TIMESTAMP
WHERE Id_datos = 1;