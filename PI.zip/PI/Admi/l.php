<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Enlace a la hoja de estilos de Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Otros estilos -->
    <link
        href='https://fonts.googleapis.com/css2?family=Lato:wght@400;700&family=Poppins:wght@400;500;600;700&display=swap'
        rel='stylesheet'>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="style.css">


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <title>Panel de administración</title>
</head>

<body>
    <?php
    require("../Datos_conexion/conexion.php");
    $admin_id = 1;
    $sql = "SELECT * FROM admi WHERE Id_admi = ?";
    $resultado = $base->prepare($sql);
    $resultado->execute([$admin_id]);
    $administrador = $resultado->fetch(PDO::FETCH_ASSOC);
    $contenido = $administrador['Foto'];

    if (isset($_GET["pagina"])) {
        if ($_GET["pagina"] == 1) {
            header("Location:index.php");
        } else {
            $pagina = $_GET["pagina"];
        }
    } else {
        $pagina = 1;
    }

    $sql_total = "SELECT * FROM usuarios";
    $resultado = $base->prepare($sql_total);
    $resultado->execute(array());

    $num_filas = $resultado->rowCount();

    $tamano_paginas = 3;

    $empezar_desde = ($pagina - 1) * $tamano_paginas;

    $total_paginas = ceil($num_filas / $tamano_paginas);

    $resultado->closeCursor();

    $sql_limite = "SELECT * FROM usuarios LIMIT $empezar_desde, $tamano_paginas";

    $resultado = $base->prepare($sql_limite);
    $resultado->execute();

    $registro = $base->query(
        "SELECT usuarios.*, YEAR(CURDATE()) - YEAR(Fecha_Nacimiento) AS Edad,
         DATE(usuarios_datos_registro.Fecha_registro) AS Fecha_registro
         FROM usuarios
         INNER JOIN usuarios_datos_registro
         ON usuarios.Id_usuario = usuarios_datos_registro.Id_usuario
         LIMIT $empezar_desde, $tamano_paginas"
    )->fetchAll(PDO::FETCH_OBJ); ?>

    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <i class='bx bxs-smile'></i>
            <span class="text">Equipo 4</span>
        </a>
        <ul class="side-menu top">
            <li id="panel">
                <a href="panel.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Panel</span>
                </a>
            </li>
            <li id="blog" class="active">
                <a href="#">
                    <i class='bx bxs-book-content'></i>
                    <span class="text">Blog</span>
                </a>
            </li>
            <li id="analytics">
                <a href="#">
                    <i class='bx bxs-doughnut-chart'></i>
                    <span class="text">Analíticas</span>
                </a>
            </li>
            <li id="messages">
                <a href="#">
                    <i class='bx bxs-message-dots'></i>
                    <span class="text">Mensajes</span>
                </a>
            </li>
            <li id="editors">
                <a href="#">
                    <i class='bx bxs-group'></i>
                    <span class="text">Editores</span>
                </a>
            </li>
            <li id="users">
                <a href="#">
                    <i class='bx bxs-user-circle'></i>
                    <span class="text">Usuarios</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="#">
                    <i class='bx bxs-cog'></i>
                    <span class="text">Ajustes</span>
                </a>
            </li>
            <li>
                <a href="#" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Cerrar sesión</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->



    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification">
                <i class='bx bxs-bell'></i>
                <span class="num">8</span>
            </a>
            <a href="#" class="profile">
                <?php echo "<img src='data:image/jpeg;base64," . base64_encode($contenido) . "' alt='Foto de perfil del administrador'>" ?>
            </a>
        </nav>
        <!-- NAVBAR -->

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <a href="generar.html" class="btn-download">
                    <i class='bx bxs-cloud-download'></i>
                    <span class="text">Generar PDF</span>
                </a>
            </div>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Usuarios Registrados</h3>
                        <i class='bx bx-search'></i>
                        <i class='bx bx-filter'></i>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>ID Usuario</th>
                                <th>Nombre</th>
                                <th>Edad</th>
                                <th>Genero</th>
                                <th>Fecha de Registro</th>
                                <th>Correo</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($registro as $usuario): ?>
                                <tr>
                                    <td>
                                        <p>
                                            <?php echo $usuario->Id_usuario; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <img src='data:image/jpeg;base64,<?php echo base64_encode($usuario->Foto); ?>'
                                            alt='Foto de perfil del usuario'>
                                        <p>
                                            <?php echo $usuario->Nombre; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo ($usuario->Edad >= 1) ? $usuario->Edad . " años" : $usuario->Edad * 365 . " días"; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo $usuario->Genero; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo $usuario->Fecha_registro; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo $usuario->Correo; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <a href="#" class="edit" data-toggle="modal">
                                            <i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i>
                                        </a>
                                    </td>
                                    <td>
                                        <a href="#" class="delete-record"
                                            data-usuario-id="<?php echo $usuario->Id_usuario; ?>" data-toggle="modal"
                                            data-target="#Eliminar">
                                            <i class="bx bx-trash" style="font-size: calc(1em + 5px); color: grey;"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </main>
    </section>
    <!-- Ventana Modal para eliminar registro -->
    <div class="modal fade" id="Eliminar" tabindex="-1" role="dialog" aria-labelledby="EliminarLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="EliminarLabel">Confirmar eliminación</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    ¿Estás seguro de que quieres eliminar este registro?
                </div>
                <div class="modal-footer">
                    <td>
                        <a href="#" class="delete-record" data-usuario-id="<?php echo $usuario->Id_usuario; ?>"
                            data-toggle="modal" data-target="#Eliminar">
                            <i class="bx bx-trash" style="font-size: calc(1em + 5px); color: grey;"></i>
                        </a>
                    </td>

                    <div class="modal-footer">
                        <!-- Botón para eliminar el registro -->
                        <form action="eliminar_usuario.php" method="POST">
                            <input type="hidden" id="id_usuario_eliminar" name="id_usuario_eliminar" value="">
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                        <!-- Botón para cancelar -->
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    </div>

                </div>
            </div>
        </div>
        <script src="script.js"></script>
        <script>
            $(document).ready(function () {
                $('.delete-record').click(function () {
                    var idUsuario = $(this).data('usuario-id');
                    $('#id_usuario_eliminar').val(idUsuario);  // Set the ID to the hidden input field
                    $('#Eliminar').modal('show');
                });
            });
        </script>
</body>

</html>