<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Enlace a la hoja de estilos de Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">


    <!-- Otros estilos -->
    <link
        href='https://fonts.googleapis.com/css2?family=Lato:wght@400;700&family=Poppins:wght@400;500;600;700&display=swap'
        rel='stylesheet'>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="style.css">


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <title>Panel de administración</title>
    <?php
    // Establecer conexión con la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "blog";

    $conn = new mysqli($servername, $username, $password, $database);

    // Verificar la conexión
    if ($conn->connect_error) {
        die ("Conexión fallida: " . $conn->connect_error);
    }
    $conn->close();
    ?>
</head>

<body>
    <?php
    require ("../Datos_conexion/conexion.php");
    $admin_id = 1;
    $sql = "SELECT * FROM admi WHERE Id_admi = ?";
    $resultado = $base->prepare($sql);
    $resultado->execute([$admin_id]);
    $administrador = $resultado->fetch(PDO::FETCH_ASSOC);
    $contenido = $administrador['Foto'];

    if (isset ($_GET["pagina"])) {
        if ($_GET["pagina"] == 1) {
            header("Location:editores.php");
        } else {
            $pagina = $_GET["pagina"];
        }
    } else {
        $pagina = 1;
    }

    $sql_total = "SELECT * FROM editores";
    $resultado = $base->prepare($sql_total);
    $resultado->execute(array());

    $num_filas = $resultado->rowCount();

    $tamano_paginas = 5;

    $empezar_desde = ($pagina - 1) * $tamano_paginas;

    $total_paginas = ceil($num_filas / $tamano_paginas);

    $resultado->closeCursor();

    $sql_limite = "SELECT * FROM editores LIMIT $empezar_desde, $tamano_paginas";

    $resultado = $base->prepare($sql_limite);
    $resultado->execute();
    $registro = $base->query(
        "SELECT editores.*, YEAR(CURDATE()) - YEAR(Fecha_Nacimiento) AS Edad,
         DATE(editores_datos.Fecha_registro) AS Fecha_registro
         FROM editores
         INNER JOIN editores_datos
         ON editores.Id_editor = editores_datos.Id_editor
         LIMIT $empezar_desde, $tamano_paginas"
    )->fetchAll(PDO::FETCH_OBJ);
    ?>

    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <i class='bx bxs-smile'></i>
            <span class="text">Equipo 4</span>
        </a>
        <ul class="side-menu top">
            <li id="panel">
                <a href="panel.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Panel</span>
                </a>
            </li>
            <li id="blog">
                <a href="#">
                    <i class='bx bxs-book-content'></i>
                    <span class="text">Blog</span>
                </a>
            </li>
            <li id="analytics">
                <a href="#">
                    <i class='bx bxs-doughnut-chart'></i>
                    <span class="text">Analíticas</span>
                </a>
            </li>
            <li id="messages">
                <a href="#">
                    <i class='bx bxs-message-dots'></i>
                    <span class="text">Mensajes</span>
                </a>
            </li>
            <li id="editors" class="active">
                <a href="#">
                    <i class='bx bxs-group'></i>
                    <span class="text">Editores</span>
                </a>
            </li>
            <li id="users">
                <a href="#">
                    <i class='bx bxs-user-circle'></i>
                    <span class="text">Usuarios</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="#">
                    <i class='bx bxs-cog'></i>
                    <span class="text">Ajustes</span>
                </a>
            </li>
            <li>
                <a href="#" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Cerrar sesión</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->



    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" hidden>
            <label for="switch-mode" class="switch-mode"></label>
            <a href="#" class="notification">
                <i class='bx bxs-bell'></i>
                <span class="num">8</span>
            </a>
            <a href="#" class="profile">
                <?php echo "<img src='data:image/jpeg;base64," . base64_encode($contenido) . "' alt='Foto de perfil del administrador'>" ?>
            </a>
        </nav>
        <!-- NAVBAR -->

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <a href="generar.html" class="btn-download">
                    <i class='bx bxs-cloud-download'></i>
                    <span class="text">Generar PDF</span>
                </a>
            </div>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Editores</h3>
                        <i class='bx bx-search'></i>
                        <i class='bx bx-filter'></i>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>ID Editores</th>
                                <th>Nombre</th>
                                <th>Edad</th>
                                <th>Genero</th>
                                <th>Fecha de Registro</th>
                                <th>Correo</th>
                                <th>
                                    <a href="#" class="add-record" data-target="#modalAñadirUsuario">
                                        <span class="material-icons" data-toggle="tooltip"
                                            title="Add">person_add_alt</span>
                                    </a>
                                </th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($registro as $editores): ?>
                                <tr>
                                    <td>
                                        <p>
                                            <?php echo $editores->Id_editor; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <img src='data:image/jpeg;base64,<?php echo base64_encode($editores->Foto); ?>'
                                            alt='Foto de perfil del editores'>
                                        <p>
                                            <?php echo $editores->Nombre; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo ($editores->Edad >= 1) ? $editores->Edad . " años" : $editores->Edad * 365 . " días"; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo $editores->Genero; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo $editores->Fecha_registro; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo $editores->Correo; ?>
                                        </p>
                                    </td>
                                    <td>
                                    <td>
                                        <a href="#" class="edit-record"
                                            data-editores-id="<?php echo $editores->Id_editor; ?>"
                                            data-editores-nombre="<?php echo $editores->Nombre; ?>"
                                            data-editores-edad="<?php echo $editores->Edad; ?>" data-toggle="modal"
                                            data-target="#Editar">
                                            <i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i>
                                        </a>
                                    </td>
                                    </td>
                                    <td>
                                        <a href="#" class="delete-record"
                                            data-editores-id="<?php echo $editores->Id_editor; ?>" data-toggle="modal"
                                            data-target="#Eliminar">
                                            <i class="bx bx-trash" style="font-size: calc(1em + 5px); color: grey;"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php
            for ($i = 1; $i <= $total_paginas; $i++) {
                echo "<a href='?pagina=" . $i . "'>" . $i . "</a>  ";
            }
            ?>
        </main>
    </section>
    <!-- Ventana Modal para eliminar registro -->
    <div class="modal fade" id="Eliminar" tabindex="-1" role="dialog" aria-labelledby="EliminarLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="EliminarLabel">Confirmar eliminación</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    ¿Estás seguro de que quieres eliminar este registro?
                </div>
                <div class="modal-footer">
                    <td>
                        <a href="#" class="delete-record" data-editores-id="<?php echo $editores->Id_editor; ?>"
                            data-toggle="modal" data-target="#Eliminar">
                            <i class="bx bx-trash" style="font-size: calc(1em + 5px); color: grey;"></i>
                        </a>
                    </td>

                    <div class="modal-footer">
                        <!-- Botón para eliminar el registro -->
                        <form action="eliminar_editor.php" method="POST">
                            <input type="hidden" id="id_editor_eliminar" name="id_editor_eliminar" value="">
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                        <!-- Botón para cancelar -->
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="Editar" tabindex="-1" role="dialog" aria-labelledby="EditarLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="EditarLabel">Editar editores</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Formulario de edición -->
                    <form id="editarForm" action="editar_usuario.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="nombre">Nombre:</label>
                            <input type="text" class="form-control" id="nombre" name="nombre"
                                value="<?php echo $row['Nombre']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                            <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento"
                                value="<?php echo $row['Fecha_Nacimiento']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="genero">Género:</label>
                            <input type="text" class="form-control" id="genero" name="genero"
                                value="<?php echo $row['Genero']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="contrasena">Contraseña:</label>
                            <input type="password" class="form-control" id="contrasena" name="contrasena">
                        </div>
                        <div class="form-group">
                            <label for="correo">Correo:</label>
                            <input type="email" class="form-control" id="correo" name="correo" required>
                        </div>
                        <br>
                        <!-- Permitir al editores cargar una nueva imagen -->
                        Cambiar Foto: <input type="file" name="foto"><br>
                        <!-- Campo oculto para el ID del editores a editar -->
                        <input type="number" id="id_usuario_editar" name="id_usuario_editar"
                            value="<?php echo $id_usuario; ?>">
                        <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Ventana Modal para añadir nuevo editores -->
    <div class="modal fade" id="modalAñadirUsuario" tabindex="-1" role="dialog"
        aria-labelledby="modalAñadirUsuarioLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalAñadirUsuarioLabel">Añadir Nuevo Usuario</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Formulario para añadir nuevos editores -->
                    <form id="añadirForm" action="añadir_usuario.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="nombre">Nombre:</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" required>
                        </div>
                        <div class="form-group">
                            <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                            <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento"
                                required>
                        </div>
                        <div class="form-group">
                            <label for="genero">Género:</label>
                            <input type="text" class="form-control" id="genero" name="genero" required>
                        </div>
                        <div class="form-group">
                            <label for="correo">Correo:</label>
                            <input type="email" class="form-control" id="correo" name="correo" required>
                        </div>
                        <div class="form-group">
                            <label for="contrasena">Contraseña:</label>
                            <input type="password" class="form-control" id="contrasena" name="contrasena" required>
                        </div>
                        <div class="form-group">
                            <label for="foto">Foto:</label>
                            <input type="file" class="form-control" id="foto" name="foto" accept="image/*">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <!-- Botón para cancelar -->
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <!-- Botón para enviar el formulario -->
                    <button type="submit" class="btn btn-primary" form="añadirForm">Añadir Usuario</button>
                </div>
            </div>
        </div>
    </div>




    <script src="script.js"></script>
    <script>
        $(document).ready(function () {
            $('.delete-record').click(function () {
                var idUsuario = $(this).data('editores-id');
                $('#id_editor_eliminar').val(idUsuario);  // Set the ID to the hidden input field
                $('#Eliminar').modal('show');
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            $('.edit-record').click(function () {
                var idUsuario = $(this).data('editores-id');
                var nombreUsuario = $(this).data('editores-nombre');
                var edadUsuario = $(this).data('editores-edad');
                var generoUsuario = $(this).data('editores-genero');
                var fechaUsuario = $(this).data('editores-fecha');
                var correoUsuario = $(this).data('editores-correo');

                // Asigna los valores a los campos del formulario de edición
                $('#id_usuario_editar').val(idUsuario);
                $('#nombre').val(nombreUsuario);
                $('#fecha_nacimiento').val(fechaUsuario); // Cambié 'fecha' a 'fecha_nacimiento'
                $('#genero').val(generoUsuario);
                $('#correo').val(correoUsuario);
                $('#Editar').modal('show');  // Muestra la ventana modal de edición
            });
        });
    </script>

    <script>
        $(document).ready(function () {
            $('.add-record').click(function () {
                console.log('Clic en el botón de añadir editores');
                $('#modalAñadirUsuario').modal('show');
            });
        });
    </script>
    <!-- Importar jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Importar Popper.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <!-- Importar Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>

</html>