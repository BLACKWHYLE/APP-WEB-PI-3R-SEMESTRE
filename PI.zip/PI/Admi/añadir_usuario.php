<?php
// Establecer conexión con la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$database = "blog";

$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $nombre = $_POST['nombre'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $genero = $_POST['genero'];
    $email = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    // Verificar si se subió una nueva imagen
    if ($_FILES['foto']['size'] > 0) {
        $foto = addslashes(file_get_contents($_FILES['foto']['tmp_name']));
    }

    // Cifrar la contraseña
    $contrasena_cifrada = password_hash($contrasena, PASSWORD_DEFAULT);

    // Insertar los datos del nuevo usuario en la tabla 'usuarios'
    $sql_insert_usuario = "INSERT INTO usuarios (Nombre, Foto, Fecha_Nacimiento, Genero, Correo, Contrasena) VALUES ('$nombre', '$foto', '$fecha_nacimiento', '$genero', '$email', '$contrasena_cifrada')";

    if ($conn->query($sql_insert_usuario) === TRUE) {
        // Obtener el ID del usuario recién insertado
        $id_usuario = $conn->insert_id;

        // Insertar datos en la tabla 'usuarios_datos_registro'
        $token = "abcd1234";
        $codigo = 1234;
        $sql_insert_datos_registro = "INSERT INTO usuarios_datos_registro (Token, Codigo, Id_usuario) VALUES ('$token', $codigo, $id_usuario)";

        if ($conn->query($sql_insert_datos_registro) === TRUE) {
            header("Location: usuarios.php");
        } else {
            echo "Error al insertar datos de registro del usuario: " . $conn->error;
        }
    } else {
        echo "Error al insertar los datos del usuario: " . $conn->error;
    }
}

$conn->close();
?>