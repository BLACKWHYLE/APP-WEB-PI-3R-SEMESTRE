<?php
    require("../Datos_conexion/conexion.php");

    $Id = $_POST['id_editor_eliminar'];

    $sql = "DELETE editores, editores_datos FROM editores
            LEFT JOIN editores_datos ON editores.Id_editor = editores_datos.Id_editor
            WHERE editores.Id_editor = :id_editor";
    $resultado = $base->prepare($sql);
    $resultado->execute(array(":id_editor" => $Id));

    header("Location:editores.php");
?>