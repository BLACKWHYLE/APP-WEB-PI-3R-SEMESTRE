<?php
// Establecer conexión con la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$database = "blog";

$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
$id_usuario = $_POST['id_usuario_editar'];
// Obtener los datos actuales del usuario
$sql = "SELECT * FROM usuarios WHERE Id_usuario = $id_usuario";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $nombre = $_POST['nombre'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $genero = $_POST['genero'];
    $contrasena = $_POST['contrasena'];
    $id_usuario = $_POST['id_usuario_editar'];

    // Verificar si se subió una nueva imagen
    if ($_FILES['foto']['size'] > 0) {
        $foto = addslashes(file_get_contents($_FILES['foto']['tmp_name']));
        // Actualizar la foto del usuario en la base de datos
        $sql_update_foto = "UPDATE usuarios SET Foto='$foto' WHERE Id_usuario=$id_usuario";
        $conn->query($sql_update_foto);
    }

    // Actualizar los datos del usuario en la base de datos
    $sql_update = "UPDATE usuarios SET Nombre='$nombre', Fecha_Nacimiento='$fecha_nacimiento', Genero='$genero', Contrasena='$contrasena' WHERE Id_usuario=$id_usuario";

    if ($conn->query($sql_update) === TRUE) {
        header("Location: usuarios.php");
    } else {
        echo "Error al actualizar los datos del usuario: " . $conn->error;
    }
}
$conn->close();
?>