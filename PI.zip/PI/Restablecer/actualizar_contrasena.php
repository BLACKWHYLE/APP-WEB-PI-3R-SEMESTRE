<?php
include 'datos_conexion/conexion.php';

$email = $_POST['email'];
$token = $_POST['token'];
$codigo = $_POST['codigo'];

try {
    $stmt = $pdo->prepare("SELECT COUNT(*), Fecha_token FROM usuarios_datos_registro WHERE Token = :token AND Codigo = :codigo AND Id_usuario IN (SELECT Id_usuario FROM usuarios WHERE Correo = :email)");
    $stmt->bindParam(':token', $token);
    $stmt->bindParam(':codigo', $codigo);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    $correcto = false;

    $count = $result['COUNT(*)'];
    $fecha_token = $result['Fecha_token'];

    $fecha_actual = date("Y-m-d H:i:s");
    $tiempo_transcurrido = strtotime($fecha_actual) - strtotime($fecha_token);
    $tiempo_maximo = 5 * 60;

    if ($count > 0) {
        if ($tiempo_transcurrido <= $tiempo_maximo) {
            echo "El token y el código son válidos.";
            $correcto = true;
        } else {
            echo "El token ha caducado.";
            $correcto = false;
        }
    } else {
        echo "El token y el código no son válidos.";
        $correcto = false;
    }
} catch (PDOException $e) {
    die("Error al ejecutar la consulta: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambiar Contraseña</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
<?php if ($correcto) { ?>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        Cambia tu Contraseña
                    </div>
                    <div class="card-body">
                        <form action="cambiar_contra.php" method="post">
                            <div class="form-group">
                                <label for="contrasena">Nueva Contraseña:</label>
                                <input type="password" class="form-control" id="contrasena" name="contrasena1" required>
                                <label for="contrasena">Confirmar Contraseña:</label>
                                <input type="password" class="form-control" id="contrasena" name="contrasena2" required>
                                <input type="hidden" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
                            </div>
                            <button type="submit" class="btn btn-primary">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } else { ?>
    <div class="alert aler-danger">Código incorrecto o vencido</div>
<?php } ?>
</body>
</html>