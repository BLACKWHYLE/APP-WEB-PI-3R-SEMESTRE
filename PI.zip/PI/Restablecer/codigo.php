<?php
include 'datos_conexion/conexion.php';

if(isset($_GET['email']) && isset($_GET['token'])){
  $email = $_GET['email'];
  $token = $_GET['token'];
}else{
  header("Location: restablecer.php");
  exit; // Detener la ejecución del script después de redireccionar
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recuperar Contraseña</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card">
          <div class="card-header">
            Código de Recuperación
          </div>
          <div class="card-body">
            <form action="actualizar_contrasena.php" method="POST">
              <div class="form-group">
                <label for="codigo">Código:</label>
                <input type="number" class="form-control" id="codigo" name="codigo" required>
                <input type="hidden" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
                <input type="hidden" class="form-control" id="token" name="token" value="<?php echo htmlspecialchars($token); ?>">
              </div>
              <button type="submit" class="btn btn-primary">Validar</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>