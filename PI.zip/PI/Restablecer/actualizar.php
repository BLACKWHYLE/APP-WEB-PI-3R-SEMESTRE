<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recuperar Contraseña</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card">
          <div class="card-header">
            Cambiar de Contraseña
          </div>
          <div class="card-body">
            <form action="actualizar_contrasena.php" method="POST">
              <div class="form-group">
                <label for="codigo">Nueva contraseña:</label>
                <input type="text" class="form-control" id="contrasena1" name="contrasena1" required>
                <label for="codigo">Confima tu contraseña:</label>
                <input type="text" class="form-control" id="contrasena2" name="contrasena2" required>
              </div>
              <button type="submit" class="btn btn-primary">Confirmar</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>