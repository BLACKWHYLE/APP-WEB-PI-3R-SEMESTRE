<?php
$servername = "localhost";
$username = "u460269596_root";
$password = "f=@=0h1LAB4";
$database = "u460269596_blog";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error al conectar: " . $e->getMessage());
}
?>