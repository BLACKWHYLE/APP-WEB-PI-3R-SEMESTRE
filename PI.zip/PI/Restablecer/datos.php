<?php
include 'datos_conexion/conexion.php';

$email = $_POST['email'];
$email = strtolower($email);

try {
    // Verificar si el correo existe en la tabla usuarios
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE Correo = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        // Generar código y token
        $codigo = rand(1000, 9999); // Número aleatorio de 4 dígitos
        $token = bin2hex(random_bytes(5));

        // Obtener la fecha y hora actual en el formato correcto
        $fecha_actual = date("Y-m-d H:i:s");

        // Actualizar el token, código y fecha en la tabla usuarios_datos_registro
        $stmt_actualizar = $pdo->prepare("UPDATE usuarios_datos_registro SET Token = :token, Codigo = :codigo, Fecha_token = :fecha_actual WHERE Id_usuario IN (SELECT Id_usuario FROM usuarios WHERE Correo = :email)");
        $stmt_actualizar->bindParam(':token', $token);
        $stmt_actualizar->bindParam(':codigo', $codigo);
        $stmt_actualizar->bindParam(':email', $email);
        $stmt_actualizar->bindParam(':fecha_actual', $fecha_actual);
        $stmt_actualizar->execute();

        // título
        $título = 'Recupera tu contraseña';

        // mensaje
        $mensaje = '
        <html>
        <head>
          <title>Recupera tu contraseña</title>
        </head>
        <body>
          <h1>Equipo 4</h1>
          <p>Restablecer contraseña</p>
          <h3>'.$codigo.'</h3>
          <a href="https://viviendoconresiliencia.com/restablecer/codigo.php?email='.urlencode($email).'&token='.$token.'">Da click aquí para restablecer</a>
          <p>Usted no sabe qué es esto. Haga caso omiso</p>
        </body>
        </html>';

        // Cabeceras del correo
        $cabeceras  = 'MIME-Version: 1.0' . "\r\n";
        $cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

        // Envío del correo
        $enviado = mail($email, $título, $mensaje, $cabeceras);

        // Manejo del estado del envío
        if ($enviado) {
            echo "El correo ha sido enviado correctamente.";
        } else {
            echo "Hubo un error al enviar el correo.";
        }
    } else {
        echo "El correo electrónico $email no está registrado en la base de datos.";
    }
} catch (PDOException $e) {
    die("Error al ejecutar la consulta: " . $e->getMessage());
}
?>