<?php
include 'datos_conexion/conexion.php';

$email = $_POST['email'];
$contra1 = $_POST['contrasena1'];
$contra2 = $_POST['contrasena2'];

echo "Email: $email<br>";
echo "Contrasena1: $contra1<br>";
echo "Contrasena2: $contra2<br>";

try {
    if ($contra1 === $contra2) {
        // Cifrar la contraseña
        $pass_cifrado = password_hash($contra1, PASSWORD_DEFAULT);
        
        echo "Hashed Password: $pass_cifrado<br>";
        
        // Actualizar la contraseña en la tabla usuarios
        $stmt_update_usuarios = $pdo->prepare("UPDATE usuarios SET Contrasena = :pass_cifrado WHERE Correo = :email");
        $stmt_update_usuarios->bindParam(':pass_cifrado', $pass_cifrado);
        $stmt_update_usuarios->bindParam(':email', $email);
        
        echo "SQL Statement: UPDATE usuarios SET Contrasena = '$pass_cifrado' WHERE Correo = '$email'<br>";
        
        $stmt_update_usuarios->execute();
        
        echo "Contraseña actualizada correctamente.";
    } else {
        echo "Las contraseñas no coinciden.";
    }
} catch (PDOException $e) {
    die("Error al ejecutar la consulta: " . $e->getMessage());
}
?>