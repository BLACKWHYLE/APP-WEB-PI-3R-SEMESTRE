<?php
// Establecer conexión con la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$database = "blog";

$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el ID del usuario a actualizar
$id_usuario = 2;

// Obtener los datos actuales del usuario
$sql = "SELECT * FROM usuarios WHERE Id_usuario = $id_usuario";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $nombre = $_POST['nombre'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $genero = $_POST['genero'];
    $contrasena = $_POST['contrasena'];

    // Verificar si se subió una nueva imagen
    if ($_FILES['foto']['size'] > 0) {
        $foto = addslashes(file_get_contents($_FILES['foto']['tmp_name']));
        // Actualizar la foto del usuario en la base de datos
        $sql_update_foto = "UPDATE usuarios SET Foto='$foto' WHERE Id_usuario=$id_usuario";
        $conn->query($sql_update_foto);
    }

    // Actualizar los datos del usuario en la base de datos
    $sql_update = "UPDATE usuarios SET Nombre='$nombre', Fecha_Nacimiento='$fecha_nacimiento', Genero='$genero', Contrasena='$contrasena' WHERE Id_usuario=$id_usuario";

    if ($conn->query($sql_update) === TRUE) {
        echo "Los datos del usuario se actualizaron correctamente.";
    } else {
        echo "Error al actualizar los datos del usuario: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Actualizar Usuario</title>
</head>
<body>

<h2>Actualizar Usuario</h2>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id=" . $id_usuario); ?>" enctype="multipart/form-data">
    Nombre: <input type="text" name="nombre" value="<?php echo $row['Nombre']; ?>"><br>
    Fecha de Nacimiento: <input type="date" name="fecha_nacimiento" value="<?php echo $row['Fecha_Nacimiento']; ?>"><br>
    Género: <input type="text" name="genero" value="<?php echo $row['Genero']; ?>"><br>
    Contraseña: <input type="password" name="contrasena"><br>
    <!-- Mostrar la imagen actual del usuario -->
    <?php 
    // Verificar si el usuario tiene una imagen
    if (!empty($row['Foto'])) {
        echo '<img src="data:image/jpeg;base64,'.base64_encode($row['Foto']).'" width="150" height="150" />';
    } else {
        echo "El usuario no tiene una imagen.";
    }
    ?>
    <br>
    <!-- Permitir al usuario cargar una nueva imagen -->
    Cambiar Foto: <input type="file" name="foto"><br>
    <input type="submit" value="Actualizar">
</form>

</body>
</html>

<?php
// Cerrar la conexión a la base de datos
$conn->close();
?>