<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

   <link rel="stylesheet" href="css/bootstrap.css">
   <link rel="stylesheet" type="text/css" href="css/style.css">
   <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
   <!-- <link rel="stylesheet" href="css/all.min.css"> -->
   <!-- <link rel="stylesheet" href="css/fontawesome.min.css"> -->
   <link href="https://tresplazas.com/web/img/big_punto_de_venta.png" rel="shortcut icon">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
   <title>Registrarse</title>
</head>

<body>
   <img class="wave" src="img/wave.png">
   <div class="container">
      <div class="img">
         <img src="img/bg.svg">
      </div>
      <div class="login-content">
         <form method="post" action="">
            <img src="img/avatar.svg">
            <h2 class="title">BIENVENIDO</h2>
            <div class="input-div one">
               <div class="i">
                  <i class="fas fa-user"></i>
               </div>
               <div class="div">
                  <h5>Nombre De Usuario</h5>
                  <input id="usuario" type="text" class="input" name="usuario" required>
               </div>
            </div>

            <div class="input-div one">
               <div class="i">
                  <i class="bi bi-envelope-fill"></i>
               </div>
               <div class="div">
                  <h5>Correo Electronico</h5>
                  <input id="correo" type="text" class="input" name="correo" required>
               </div>
            </div>

            <div class="input-div pass">
               <div class="i">
                  <i class="fas fa-lock"></i>
               </div>
               <div class="div">
                  <h5>Contraseña</h5>
                  <input type="password" id="input" class="input" name="password" required>
               </div>
            </div>
            <div class="view">
               <div class="fas fa-eye verPassword" onclick="vista()" id="verPassword"></div>
            </div>

            <div class="input-div">
               <div class="i">
                  <i class="bi bi-gender-ambiguous"></i>
               </div>
            <div class="div">
               <h5></h5>
               <select id="genero" class="input-genero" name="genero" required>
               <option value="" disabled selected>Selecciona tu genero</option>
               <option value="masculino">Masculino</option>
               <option value="femenino">Femenino</option>
               </select>
               </div>
            </div>   

            <div class="input-div">
               <div class="i">
                  <i class="bi bi-calendar3"></i>
               </div>
            <div class="div">
               <input type="date" id="fecha_nacimiento" class="input-fecha" name="fecha_nacimiento" required>
               </div>
            </div>

            <input name="btnregistro" class="btn" type="submit" value="REGISTRARSE">
         </form>
      </div>
   </div>
   <script src="js/fontawesome.js"></script>
   <script src="js/main.js"></script>
   <script src="js/main2.js"></script>
   <script src="js/jquery.min.js"></script>
   <script src="js/bootstrap.js"></script>
   <script src="js/bootstrap.bundle.js"></script>

   <?php
try {
    // Conexión a la base de datos
    $base = new PDO('mysql:host=localhost; dbname=blog', 'root', '');
    $base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $base->exec("SET CHARACTER SET utf8");

    // Verificar si se envió el formulario
    if(isset($_POST['btnregistro'])) {
        // Recoger los datos del formulario
        $nombre = $_POST['usuario'];
        $fecha_nacimiento = $_POST['fecha_nacimiento'];
        $genero = $_POST['genero'];
        $correo = $_POST['correo'];
        $contrasena = $_POST['password'];

        // Preparar la consulta SQL para insertar los datos en la tabla usuarios
        $consulta = $base->prepare("INSERT INTO usuarios (Nombre, Fecha_Nacimiento, Genero, Correo, Contrasena) VALUES (:nombre, :fecha_nacimiento, :genero, :correo, :contrasena)");

        // Bind de parámetros
        $consulta->bindParam(':nombre', $nombre);
        $consulta->bindParam(':fecha_nacimiento', $fecha_nacimiento);
        $consulta->bindParam(':genero', $genero);
        $consulta->bindParam(':correo', $correo);
        $consulta->bindParam(':contrasena', $contrasena);

        // Ejecutar la consulta
        $consulta->execute();

       // Redireccionar a la página index.html
       header('Location: ../index.html');
       exit(); // Asegura que el script se detenga después de la redirección
    }
} catch (Exception $e) {
    // Manejo de errores
    die('Error: ' . $e->getMessage());
}
?>


</body>

</html>