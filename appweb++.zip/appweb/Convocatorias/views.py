from django.shortcuts import render

# Create your views here.
def convocatorias(request):
    return render(request, "Convocatorias/convocatorias.html")