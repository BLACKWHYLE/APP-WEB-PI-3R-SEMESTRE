from django.urls import path

from Convocatorias import views

urlpatterns = [
    path('', views.convocatorias, name="Convocatorias"),
]