from django.contrib import admin
from .models import Becario, DatosPersonales, Domicilio, InformacionAcademica, InformacionBeca, EstadosBeca, RenovacionesBeca, EstudioSocioeconomico

@admin.register(Becario)
class BecarioAdmin(admin.ModelAdmin):
    list_display = ('usuario', 'fecha_registro', 'estado_actual')
    search_fields = ('usuario__nombre', 'estado_actual')
    list_filter = ('fecha_registro', 'estado_actual')

@admin.register(DatosPersonales)
class DatosPersonalesAdmin(admin.ModelAdmin):
    list_display = ('becario', 'nombre', 'apellidos', 'email', 'curp')
    search_fields = ('nombre', 'apellidos', 'email', 'curp')
    list_filter = ('becario',)

@admin.register(Domicilio)
class DomicilioAdmin(admin.ModelAdmin):
    list_display = ('becario', 'direccion', 'ciudad', 'estado', 'codigo_postal')
    search_fields = ('becario__usuario__nombre', 'direccion', 'ciudad', 'estado', 'codigo_postal')
    list_filter = ('becario',)

@admin.register(InformacionAcademica)
class InformacionAcademicaAdmin(admin.ModelAdmin):
    list_display = ('becario', 'nivel_academico', 'institucion_educativa', 'carrera', 'promedio')
    search_fields = ('becario__usuario__nombre', 'nivel_academico', 'institucion_educativa', 'carrera')
    list_filter = ('becario',)

@admin.register(InformacionBeca)
class InformacionBecaAdmin(admin.ModelAdmin):
    list_display = ('becario', 'beca_asignada', 'monto_beca', 'fecha_inicio_beca', 'fecha_fin_beca')
    search_fields = ('beca_asignada', 'monto_beca')
    list_filter = ('becario',)

@admin.register(EstadosBeca)
class EstadosBecaAdmin(admin.ModelAdmin):
    list_display = ('becario', 'estado', 'fecha_cambio', 'comentarios')
    search_fields = ('estado', 'comentarios')
    list_filter = ('becario', 'fecha_cambio')

@admin.register(RenovacionesBeca)
class RenovacionesBecaAdmin(admin.ModelAdmin):
    list_display = ('becario', 'fecha_renovacion', 'periodo', 'estado', 'comentarios')
    search_fields = ('periodo', 'estado', 'comentarios')
    list_filter = ('becario', 'fecha_renovacion')

@admin.register(EstudioSocioeconomico)
class EstudioSocioeconomicoAdmin(admin.ModelAdmin):
    list_display = ('becario', 'ingreso_mensual', 'numero_dependientes', 'vivienda', 'ocupacion_padres', 'nivel_educativo_padres')
    search_fields = ('ingreso_mensual', 'vivienda', 'ocupacion_padres', 'nivel_educativo_padres')
    list_filter = ('becario',)