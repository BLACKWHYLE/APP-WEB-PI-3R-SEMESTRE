# becarios/urls.py
from django.urls import path
from .views import listar_becarios

urlpatterns = [
    path('', listar_becarios, name='listar_becarios'),
]