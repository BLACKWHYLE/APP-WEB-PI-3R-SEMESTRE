from django.db import models
from Usuarios.models import Usuario  # Importar el modelo Usuario

class Becario(models.Model):
    id = models.AutoField(primary_key=True)
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE)  # Referencia a Usuario
    fecha_registro = models.DateTimeField(auto_now_add=True)
    estado_actual = models.CharField(max_length=20)

    def __str__(self):
        return f"Becario: {self.usuario.nombre}"

class DatosPersonales(models.Model):
    id = models.AutoField(primary_key=True)
    becario = models.OneToOneField(Becario, on_delete=models.CASCADE)
    nombre = models.CharField(max_length=50)
    apellidos = models.CharField(max_length=50)
    fecha_nacimiento = models.DateField()
    telefono = models.CharField(max_length=15)
    email = models.EmailField(max_length=100, unique=True)
    curp = models.CharField(max_length=18, unique=True)
    rfc = models.CharField(max_length=13)
    nacionalidad = models.CharField(max_length=50)
    genero = models.CharField(max_length=20)

    def __str__(self):
        return f"Datos Personales de {self.nombre} {self.apellidos}"

class Domicilio(models.Model):
    id = models.AutoField(primary_key=True)
    becario = models.OneToOneField(Becario, on_delete=models.CASCADE)
    direccion = models.TextField()
    ciudad = models.CharField(max_length=50)
    estado = models.CharField(max_length=50)
    codigo_postal = models.CharField(max_length=10)
    pais = models.CharField(max_length=50)

    def __str__(self):
        return f"Domicilio de {self.becario.usuario.nombre}"

class InformacionAcademica(models.Model):
    becario = models.OneToOneField(Becario, on_delete=models.CASCADE, primary_key=True)
    nivel_academico = models.CharField(max_length=50)
    institucion_educativa = models.CharField(max_length=100)
    carrera = models.CharField(max_length=100)
    promedio = models.DecimalField(max_digits=4, decimal_places=2)

    def __str__(self):
        return f"Información Académica de {self.becario.usuario.nombre}"

class InformacionBeca(models.Model):
    becario = models.OneToOneField(Becario, on_delete=models.CASCADE, primary_key=True)
    beca_asignada = models.CharField(max_length=100)
    monto_beca = models.DecimalField(max_digits=10, decimal_places=2)
    fecha_inicio_beca = models.DateField()
    fecha_fin_beca = models.DateField()

    def __str__(self):
        return f"Información de Beca para {self.becario.usuario.nombre}"

class EstadosBeca(models.Model):
    id = models.AutoField(primary_key=True)
    becario = models.ForeignKey(Becario, on_delete=models.CASCADE)
    estado = models.CharField(max_length=20)
    fecha_cambio = models.DateTimeField(auto_now_add=True)
    comentarios = models.TextField()

    def __str__(self):
        return f"Estado de Beca para {self.becario.usuario.nombre}"

class RenovacionesBeca(models.Model):
    id = models.AutoField(primary_key=True)
    becario = models.ForeignKey(Becario, on_delete=models.CASCADE)
    fecha_renovacion = models.DateTimeField(auto_now_add=True)
    periodo = models.CharField(max_length=20)
    estado = models.CharField(max_length=20)
    comentarios = models.TextField()

    def __str__(self):
        return f"Renovación de Beca para {self.becario.usuario.nombre}"

class EstudioSocioeconomico(models.Model):
    id = models.AutoField(primary_key=True)
    becario = models.ForeignKey(Becario, on_delete=models.CASCADE)
    ingreso_mensual = models.DecimalField(max_digits=15, decimal_places=2)
    numero_dependientes = models.IntegerField()
    vivienda = models.CharField(max_length=50)
    ocupacion_padres = models.CharField(max_length=50)
    nivel_educativo_padres = models.CharField(max_length=50)
    comentarios = models.TextField()

    def __str__(self):
        return f"Estudio Socioeconómico de {self.becario.usuario.nombre}"