from django.shortcuts import render
from .models import Becario, DatosPersonales

def listar_becarios(request):
    becarios = Becario.objects.all().select_related('usuario', 'datospersonales')
    return render(request, 'becarios/lista_becarios.html', {'becarios': becarios})