# coordinadores/admin.py
from django.contrib import admin
from .models import Coordinador

@admin.register(Coordinador)
class CoordinadorAdmin(admin.ModelAdmin):
    list_display = ('usuario', 'departamento')
    search_fields = ('usuario__nombre', 'departamento')