# coordinadores/models.py
from django.db import models
from Usuarios.models import Usuario

class Coordinador(models.Model):
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE)
    departamento = models.CharField(max_length=50)

    def __str__(self):
        return self.usuario.nombre