# usuarios/models.py
from django.db import models

class Usuario(models.Model):
    nombre = models.CharField(max_length=50)
    email = models.EmailField(unique=True)
    contrasena = models.CharField(max_length=100)
    fecha_registro = models.DateTimeField(auto_now_add=True)
    fecha_nacimiento = models.DateField()
    foto = foto = models.ImageField(upload_to='usuarios')

    def __str__(self):
        return self.nombre