# donantes/models.py
from django.db import models
from Usuarios.models import Usuario

class Donante(models.Model):
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE)
    monto_donado = models.DecimalField(max_digits=10, decimal_places=2)
    fecha_ultima_donacion = models.DateField()

    def __str__(self):
        return self.usuario.nombre

class Donacion(models.Model):
    donante = models.ForeignKey(Donante, on_delete=models.CASCADE)
    monto = models.DecimalField(max_digits=10, decimal_places=2)
    fecha_donacion = models.DateTimeField(auto_now_add=True)
    metodo_pago = models.CharField(max_length=50)
    referencia_pago = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.donante.usuario.nombre} - {self.monto}"