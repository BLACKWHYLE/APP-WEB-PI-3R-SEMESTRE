# donantes/admin.py
from django.contrib import admin
from .models import Donante, Donacion

@admin.register(Donante)
class DonanteAdmin(admin.ModelAdmin):
    list_display = ('usuario', 'monto_donado', 'fecha_ultima_donacion')
    search_fields = ('usuario__nombre', 'monto_donado')

@admin.register(Donacion)
class DonacionAdmin(admin.ModelAdmin):
    list_display = ('donante', 'monto', 'fecha_donacion', 'metodo_pago')
    search_fields = ('donante__usuario__nombre', 'monto')
    list_filter = ('fecha_donacion',)