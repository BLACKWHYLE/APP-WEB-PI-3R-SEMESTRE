from django.shortcuts import render, HttpResponse

# Create your views here.

def home(request):
    return render(request, "Inicio/home.html")

def tienda(request):
    return render(request, "Inicio/tienda.html")

def blog(request):
    return render(request, "Inicio/blog.html")

def contacto(request):
    return render(request, "Inicio/contacto.html")