from django.shortcuts import render

# Create your views here.

def programas(request):
    return render(request, "Programas/programas.html")