<?php
// Verificar si se han enviado los datos del formulario
if(isset($_POST['btningresar'])) {
    // Incluir el archivo de conexión
    require_once '../Datos_conexion/conexion2.php';

    // Recuperar los valores del formulario
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    try {
        // Consulta SQL para obtener los datos del usuario
        $sql = "SELECT Id_editor, Nombre, Correo, Contrasena FROM editores WHERE Correo = '$correo'";
        $result = $conexion->query($sql);

        // Verificar si se encontró algún resultado
        if ($result->num_rows > 0) {
            // Obtener los datos del usuario
            $row = $result->fetch_assoc();
            $id_usuario = $row['Id_editor'];
            $nombre_usuario = $row['Nombre'];
            $correo_usuario = $row['Correo'];
            $contrasena_cifrada = $row['Contrasena'];

            // Verificar si la contraseña proporcionada coincide con la contraseña cifrada almacenada
            if (password_verify($contrasena, $contrasena_cifrada)) {
                // Inicio de sesión exitoso

                // Crear una cookie para recordar la sesión del correo electrónico
                setcookie('email_editor', $correo_usuario, time() + 4000, '/');

                // Mostrar mensaje de bienvenida
                header("Location: ../editor/editor.php");
                exit; // Finalizar el script después de redirigir
            } else {
                // Inicio de sesión fallido
                echo "Correo o contraseña incorrectos.";
            }
        } else {
            // Correo no encontrado en la base de datos
            echo "Correo no encontrado.";
        }
    } catch (Exception $e) {
        // Error en la consulta SQL
        echo "Error: " . $e->getMessage();
    }
}