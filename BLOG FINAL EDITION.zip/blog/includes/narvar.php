<?php
echo '<header class="navbar navbar-toggleable-md navbar-light bg-white fixed-top mediumnavigation">';
echo '<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsWow" aria-controls="navbarsWow" aria-expanded="false" aria-label="Toggle navigation">';
echo '<span class="navbar-toggler-icon"></span>';
echo '</button>';
echo '<div class="container">';
// Begin Logo
echo '<a class="navbar-brand" href="index.html">';
echo '<img src="assets/images/logo.png" alt="Affiliates - Free Bootstrap Template">';
echo '</a>';
// End Logo
// Begin Menu
echo '<div class="collapse navbar-collapse" id="navbarsWow">';
// Begin Menu
echo '<ul class="navbar-nav ml-auto">';
echo '<li class="nav-item">';
echo '<a class="nav-link" href="index.html">INICIO</a>';
echo '</li>';
echo '<li class="nav-item">';
echo '<a class="nav-link" href="category.php">PUBLICACIONES</a>';
echo '</li>';
echo '<li class="nav-item">';
echo '<a class="nav-link" href="about.html">ACERCA DE</a>';
echo '</li>';
echo '<li class="nav-item">';
echo '<a class="nav-link" href="contact.html">CONTACTO</a>';
echo '</li>';
echo '<li class="nav-item">';
echo '<a class="nav-link"  href="login/login.php">INICIA SESION</a>';
echo '</li>';
echo '</ul>';
// End Menu
echo '</div>';
echo '</div>';
echo '</header>';
?>
