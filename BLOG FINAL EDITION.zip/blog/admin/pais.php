<?php
    // Dirección IP del visitante
    $ip_visitante = $_SERVER['REMOTE_ADDR'];

    // Si la dirección IP es localhost (IPv6) asigna una cadena vacía, de lo contrario, usa la dirección IP
    $ip_usuario = ($ip_visitante == '::1') ? '' : $ip_visitante;

    // Obtener los datos de geolocalización mediante el servicio de GeoPlugin
    $datos_geoplugin = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip=' . $ip_usuario));

    // Mostrar el país del visitante
    echo ' País: ' . $datos_geoplugin['geoplugin_countryName'];
?>