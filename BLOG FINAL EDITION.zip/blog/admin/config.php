<?php
// CONFIGURACION DE GOOGLE
$clientID = '576668169652-1ieasqr3dlpchj7tga9ujp18rcv625sn.apps.googleusercontent.com';
$clientSecret = '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';
$redirectUri = 'http://localhost/pi/login_admi/datos_admi.php';
?>