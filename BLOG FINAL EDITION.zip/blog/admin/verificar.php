<?php
// Verificar si se han enviado los datos del formulario
if(isset($_POST['btningresar'])) {
    // Incluir el archivo de conexión
    require_once '../Datos_conexion/conexion.php';

    // Recuperar los valores del formulario
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    try {
        // Consulta SQL para obtener la contraseña cifrada del usuario
        $sql = "SELECT Id_admi, Nombre, Correo, Contrasena FROM admi WHERE Correo = :correo";
        $stmt = $base->prepare($sql);
        $stmt->bindParam(':correo', $correo);
        $stmt->execute();

        // Verificar si se encontró algún resultado
        if ($stmt->rowCount() > 0) {
            // Obtener los datos del usuario
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $id_usuario = $row['Id_admi'];
            $nombre_usuario = $row['Nombre'];
            $correo_usuario = $row['Correo'];
            $contrasena_cifrada = $row['Contrasena'];

            // Destruye Cookie de notificaciones
            setcookie('notificationClicked', '', time() - 3600, '/');

            // Verificar si la contraseña proporcionada coincide con la contraseña cifrada almacenada
            if (password_verify($contrasena, $contrasena_cifrada)) {
                // Inicio de sesión exitoso

                // Crear una cookie para recordar la sesión del correo electrónico
                setcookie('user_email', $correo_usuario, time() + 900, '/'); // Cookie válida por 15 minutos

                // Crear una cookie para recordar la sesión del ID del usuario
                setcookie('id_usuario', $id_usuario, time() + 900, '/'); // Cookie válida por 15 minutos

                // Mostrar mensaje de bienvenida
                header("Location: ../Admi/panel.php");
                exit; // Finalizar el script después de redirigir
            } else {
                // Inicio de sesión fallido
                echo "Correo o contraseña incorrectos.";
            }
        } else {
            // Correo no encontrado en la base de datos
            echo "Correo no encontrado.";
        }
    } catch (Exception $e) {
        // Error en la consulta SQL
        echo "Error: " . $e->getMessage();
    }
}

// Verificar si hay una cookie de sesión válida
if(isset($_COOKIE['user_email']) && isset($_COOKIE['id_usuario'])) {
    // El usuario tiene cookies válidas, puedes redirigirlo a la página principal o permitirle el acceso a ciertas partes del sitio
    // Aquí podrías redirigir al usuario a otra página o realizar otras acciones según sea necesario
    $correo_usuario = $_COOKIE['user_email'];
    $id_usuario = $_COOKIE['id_usuario'];
    // Aquí puedes hacer lo que necesites con las variables $correo_usuario y $id_usuario
} else {
    // No hay cookies válidas, redirigir al usuario al formulario de inicio de sesión
    header('Location: index.php');
    exit; // Finalizar el script para evitar que se procese más código
}
?>