<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="assets/images/favicon.ico">
<title>Silented Voices</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">
<link href="../assets/css/theme.css" rel="stylesheet">
<!-- Begin tracking codes here, including ShareThis/Analytics -->
    
<!-- End tracking codes here, including ShareThis/Analytics -->
</head>
<body class="layout-page">
<!-- Begin Menu Navigation
================================================== -->
<header class="navbar navbar-toggleable-md navbar-light bg-white fixed-top mediumnavigation">
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsWow" aria-controls="navbarsWow" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="container">
	<!-- Begin Logo -->
	<a class="navbar-brand" href="index.html">
	<img src="../assets/images/logo.png" alt="Affiliates - Free Bootstrap Template">
	</a>
	<!-- End Logo -->
	<!-- Begin Menu -->
	<div class="collapse navbar-collapse" id="navbarsWow">
		<!-- Begin Menu -->
		<ul class="navbar-nav ml-auto">
            <li class="nav-item">
			<a class="nav-link" href="editor.php">PUBLICACIONES</a>
			</li>
            <li class="nav-item">
			<a class="nav-link"  href="../index.html">CERRAR SESION</a>
			</li>
            <?php
            // Aquí puedes agregar lógica PHP para mostrar opciones de menú adicionales
            ?>
		</ul>
		<!-- End Menu -->
	</div>
</div>
</header>
<!-- End Menu Navigation
================================================== -->
<div class="site-content">
	<div class="container">
		<!-- Content
    ================================================== -->
		<div class="main-content">
			<!-- Begin Article
            ================================================== -->
			<div class="row">
				<!-- Sidebar -->
				<div class="col-sm-4">
					<div class="sidebar">
						<div class="sidebar-section">
							<h5><span>DATO INTERESTANTE</span></h5>
                            <p>La pobreza extrema ha disminuido significativamente en las últimas décadas, pero aún afecta a más de 700 millones de personas en todo el mundo.</p>
						</div>
						<div class="sidebar-section">
							<h5><span>UTIL PARA TI</span></h5>
							<ul>
								<li><a target="_blank" href="https://www.un.org/es/get-involved">Colabora con la ONU</a></li>
								<li><a target="blank" href="https://www.un.org/es/our-work#:~:text=Proteger%20los%20derechos%20humanos,Defender%20el%20derecho%20internacional">Desafios globales de la ONU</a></li>
								<li><a target="_blank" href="https://www.un.org/es/global-issues/water">El agua como factor de gran importancia</a></li>
							    <li><a target="_blank" href="https://www.un.org/es/global-issues/food">La importancia de la alimentacion</a></li>
							    <li><a target="_blank" href="https://www.un.org/es/global-issues/">Vision general</a></li>
							</ul>
						</div>
					</div>
				</div>
				<!-- End Sidebar -->
				<!-- Article Content -->
				<div class="col-sm-8">
					<div class="content">
                    <?php
// Verificar si se ha proporcionado un ID de publicación válido en la URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    try {
        // Conexión a la base de datos
        $base = new PDO('mysql:host=localhost; dbname=blog', 'root', '');
        $base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $base->exec("SET CHARACTER SET utf8");

        // Recuperar el ID de la publicación desde la URL
        $id_publicacion = $_GET['id'];

        // Consultar la base de datos para obtener la publicación con el ID especificado
        $consulta_publicacion = $base->prepare("SELECT * FROM publicaciones WHERE Id_publicacion = ?");
        $consulta_publicacion->execute([$id_publicacion]);
        $publicacion = $consulta_publicacion->fetch(PDO::FETCH_ASSOC);

        // Verificar si se encontró la publicación
        if ($publicacion) {
            // Mostrar la publicación completa
            echo '<h1>' . $publicacion['Titulo'] . '</h1>';
    
            // Verificar si se proporcionó una imagen válida en la publicación
            if (!empty($publicacion['Imagen'])) {
                // Mostrar la imagen desde la base de datos como base64
                echo '<img class="img-fluid" src="data:image/jpeg;base64,' . base64_encode($publicacion['Imagen']) . '" alt="' . $publicacion['Titulo'] . '">';
            } else {
                // Si no se proporcionó una imagen válida, mostrar un mensaje de error
                echo '<p>No se proporcionó una imagen válida.</p>';
            }

            echo '<p>' . $publicacion['Contenido'] . '</p>';
        } else {
            // Si no se encuentra la publicación, mostrar un mensaje de error
            echo '<p>No se encontró la publicación.</p>';
        }

        // Cerrar la conexión a la base de datos
        $base = null;
    } catch (Exception $e) {
        // Manejar errores
        die('Error: ' . $e->getMessage());
    }
} else {
    // Si no se proporcionó un ID de publicación válido en la URL, mostrar un mensaje de error
    echo '<p>No se proporcionó un ID de publicación válido.</p>';
}
?>
					</div>
				</div>
			</div>
			<!-- End Article -->
		</div>
	</div>
</div>

<div id="disqus_thread"></div>
<script>
    /**
    *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
    *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables    */
    /*
    var disqus_config = function () {
    this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
    this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
    };
    */
    (function() { // DON'T EDIT BELOW THIS LINE
    var d = document, s = d.createElement('script');
    s.src = 'https://blog-4sybp35byv.disqus.com/embed.js';
    s.setAttribute('data-timestamp', +new Date());
    (d.head || d.body).appendChild(s);
    })();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>

<!-- Begin Footer
    ================================================== -->
	<footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="footer-widget">
                        <a href="contact.html">
                        <img src="../assets/images/logo-foot.jpg" alt="logo footer" width="50%">
                        </a>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="footer-widget">
                        <h5 class="title">Recursos</h5>
                        <ul>
                            <li><a target="_blank" href="https://www.un.org/es/get-involved">Colabora con la ONU</a></li>
                            <li><a target="_blank" href="https://www.un.org/es/our-work#:~:text=Proteger%20los%20derechos%20humanos,Defender%20el%20derecho%20internacional">Desafios globales de la ONU</a></li>
                            <li><a target="_blank" href="https://www.un.org/es/global-issues/water">El agua como factor de gran importancia</a></li>
                            <li><a target="_blank" href="https://www.un.org/es/global-issues/food">La importancia de la alimentacion</a></li>
                            <li><a target="_blank" href="https://www.un.org/es/global-issues/">Vision general</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="footer-widget">
                        <h5 class="title">Autor</h5>
                        <ul>
                            <li><a href="/about.html">Acerca de</a></li>
                            <li><a href="/contact.html">Contacto</a></li>
                            
                            
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="footer-widget">
                        <h5 class="title">Acciones Especiales</h5>
                        <ul>
    
                            <li><a href="">Inicia sesion como administrador</a></li>
                            
                        </ul>
                        
                    </div>
                </div>
            </div>
            <div class="copyright">
                <p class="pull-left">
                     Copyright © 2024 Proyecto Integrador UDC
                </p>
                <p class="pull-right">
                    <!-- Leave credit to author unless you own a commercial license: https://www.wowthemes.net/freebies-license/ -->
                    <a target="_blank" href="index.html">"Blog Web"</a> - Diseñado por Ingenieros de la UDC
                </p>
                <div class="clearfix">
                </div>
            </div>
        </div>
        </footer>
	<!-- End Footer
    ================================================== -->
</div>
<script src="assets/js/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<script src="assets/js/ie10-viewport-bug-workaround.js"></script>
<script src="assets/js/masonry.pkgd.min.js"></script>
<script src="assets/js/theme.js"></script>
<script id="dsq-count-scr" src="//blog-4sybp35byv.disqus.com/count.js" async></script>
</body>
</html>
