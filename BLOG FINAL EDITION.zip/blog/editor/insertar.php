<?php
// Incluir el archivo de conexión
include '../Datos_conexion/conexion2.php';

// Procesar el formulario si se envió
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar datos del formulario y validarlos
    $titulo = htmlspecialchars($_POST['titulo']);
    $descripcion = htmlspecialchars($_POST['descripcion']);
    $contenido = htmlspecialchars($_POST['contenido']);

    // Verificar si se ha subido una imagen y validarla
    if ($_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        // Guardar la imagen en la base de datos
        $imagen_data = file_get_contents($_FILES['imagen']['tmp_name']);

        // Obtener el ID del editor actual usando su correo electrónico almacenado en la cookie
        if (isset($_COOKIE['email_editor'])) {
            $correo = $_COOKIE['email_editor'];
            $consulta_editor = "SELECT Id_editor FROM editores WHERE Correo = '$correo'";
            $resultado_editor = mysqli_query($conexion, $consulta_editor);

            if ($resultado_editor && mysqli_num_rows($resultado_editor) > 0) {
                $fila_editor = mysqli_fetch_assoc($resultado_editor);
                $id_editor = $fila_editor['Id_editor'];

                // Escapar el valor de $imagen_data
                $imagen_data_escaped = mysqli_real_escape_string($conexion, $imagen_data);

                // Insertar datos en la tabla publicaciones
                $insert_query_publicaciones = "INSERT INTO publicaciones (Titulo, Contenido, Brevedesc, Imagen, Id_editor) VALUES ('$titulo', '$contenido', '$descripcion', '$imagen_data_escaped', '$id_editor')";

                if (mysqli_query($conexion, $insert_query_publicaciones)) {
                    // Obtener el ID de la última fila insertada en publicaciones
                    $id_publicacion = mysqli_insert_id($conexion);
                    
                    // Insertar datos en la tabla publicaciones_datos
                    $insert_query_publicaciones_datos = "INSERT INTO publicaciones_datos (Estatus, Id_publicacion) VALUES ('Pendiente', '$id_publicacion')";
                    if (mysqli_query($conexion, $insert_query_publicaciones_datos)) {
                        echo "La publicación se ha insertado correctamente con ID: $id_publicacion";
                        header ('Location: editor.php');
                    } else {
                        echo "Error al insertar datos en la tabla publicaciones_datos: " . mysqli_error($conexion);
                    }
                } else {
                    // Manejar errores en caso de que la consulta falle
                    echo "Error al insertar datos en la tabla publicaciones: " . mysqli_error($conexion);
                }
            } else {
                echo "Error: No se pudo encontrar el editor con el correo electrónico proporcionado.";
            }
        } else {
            echo "Error: No se proporcionó el correo electrónico del editor.";
        }
    } else {
        echo "Error: No se ha subido ninguna imagen.";
    }
}
?>