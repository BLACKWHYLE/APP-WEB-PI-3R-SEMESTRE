<?php
// Destruir las cookies de sesión
setcookie('editor_email', '', time() - 5000, '/');

// Redirigir al usuario al formulario de inicio de sesión
header('Location: ../index.php');
exit; // Finalizar el script después de redirigir
?>