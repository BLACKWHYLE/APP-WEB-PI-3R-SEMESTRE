<?php
require("../Datos_conexion/conexion.php");

$Id = $_POST['id_usuario_eliminar'];
$pagina = $_POST['pagina'];

$sql = "DELETE usuarios, usuarios_datos_registro FROM usuarios
        LEFT JOIN usuarios_datos_registro ON usuarios.Id_usuario = usuarios_datos_registro.Id_usuario
        WHERE usuarios.Id_usuario = :id_usuario";
$resultado = $base->prepare($sql);
$resultado->execute(array(":id_usuario" => $Id));

header("Location: usuarios.php?pagina=" . $pagina);
?>