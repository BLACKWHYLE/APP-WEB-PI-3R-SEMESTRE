<?php
// Establecer conexión con la base de datos
require("../Datos_conexion/conexion2.php");

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $id_editor = $_POST['id_editor_editar']; // Obtener el ID del editor a actualizar
    $nombre = $_POST['nombre'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $genero = $_POST['genero'];
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];
    $pagina = $_POST['pagina'];

    // Verificar si se proporcionó una contraseña
    if (!empty($contrasena)) {
        // Hash de la contraseña
        $contrasena = password_hash($contrasena, PASSWORD_DEFAULT);
    } else {
        // Si la contraseña está vacía, no hacer ningún cambio en la base de datos
        // Eliminar la contraseña del array para evitar actualizarla en la consulta SQL
        unset($contrasena);
    }

    // Verificar si se subió una nueva imagen
    if ($_FILES['foto']['size'] > 0) {
        $foto = addslashes(file_get_contents($_FILES['foto']['tmp_name']));

        // Construir la consulta SQL para actualizar los datos del editor
        $sql_update = "UPDATE editores 
                       SET Nombre='$nombre', 
                           Fecha_Nacimiento='$fecha_nacimiento', 
                           Genero='$genero', 
                           Correo='$correo'";

        // Agregar la contraseña a la consulta si no está vacía
        if (isset($contrasena)) {
            $sql_update .= ", Contrasena='$contrasena'";
        }

        // Agregar la foto a la consulta
        $sql_update .= ", Foto='$foto' WHERE Id_editor=$id_editor";

        // Ejecutar la consulta
        if (mysqli_query($conexion, $sql_update)) {
            header("Location: editores.php?pagina=" . $pagina);
            exit; // Terminar el script después de redireccionar
        } else {
            echo "Error al actualizar los datos del editor: " . mysqli_error($conexion);
        }
    } else {
        echo "Por favor, seleccione una imagen.";
    }
}
?>