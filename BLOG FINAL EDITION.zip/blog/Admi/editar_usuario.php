<?php
require("../Datos_conexion/conexion2.php");

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $id_usuario = $_POST['id_usuario_editar']; // Obtener el ID del usuario a actualizar
    $nombre = $_POST['nombre'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $genero = $_POST['genero'];
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];
    $pagina = $_POST['pagina'];

    // Verificar si la contraseña no está vacía para actualizarla
    $contrasena_query = !empty($contrasena) ? ", Contrasena='" . password_hash($contrasena, PASSWORD_DEFAULT) . "'" : "";

    // Verificar si se subió una nueva imagen
    if ($_FILES['foto']['size'] > 0) {
        $foto = file_get_contents($_FILES['foto']['tmp_name']);
        // Verificar la conexión (ya está verificada en el archivo de conexión)
        
        // Escapar los datos para prevenir inyección de SQL (opcional dependiendo del origen de los datos)
        $nombre = mysqli_real_escape_string($conexion, $nombre);
        $fecha_nacimiento = mysqli_real_escape_string($conexion, $fecha_nacimiento);
        $genero = mysqli_real_escape_string($conexion, $genero);
        $correo = mysqli_real_escape_string($conexion, $correo);

        // Actualizar los datos del usuario en la base de datos
        $sql_update = "UPDATE usuarios 
                       SET Nombre='$nombre', 
                           Fecha_Nacimiento='$fecha_nacimiento', 
                           Genero='$genero', 
                           Correo='$correo' 
                           $contrasena_query";
        
        // Si se ha subido una foto, se agrega a la consulta SQL
        $foto_query = !empty($foto) ? ", Foto=?" : "";
        $sql_update .= $foto_query;

        $sql_update .= " WHERE Id_usuario=$id_usuario";

        // Preparar la consulta con la imagen si se ha subido
        $stmt = mysqli_prepare($conexion, $sql_update);
        if (!empty($foto)) {
            mysqli_stmt_bind_param($stmt, "s", $foto);
        }

        // Ejecutar la consulta
        if (mysqli_stmt_execute($stmt)) {
            header("Location: usuarios.php?pagina=" . $pagina);
            exit; // Terminar el script después de redireccionar
        } else {
            echo "Error al actualizar los datos del usuario: " . mysqli_error($conexion);
        }

        // Cerrar la declaración y la conexión
        mysqli_stmt_close($stmt);
        mysqli_close($conexion);
    } else {
        // Si no se subió una foto, se omite la actualización de la foto
        $sql_update = "UPDATE usuarios 
                       SET Nombre=?, 
                           Fecha_Nacimiento=?, 
                           Genero=?, 
                           Correo=?
                           $contrasena_query
                       WHERE Id_usuario=?";

        // Preparar la consulta sin la imagen
        $stmt = mysqli_prepare($conexion, $sql_update);
        mysqli_stmt_bind_param($stmt, "ssssi", $nombre, $fecha_nacimiento, $genero, $correo, $id_usuario);

        // Ejecutar la consulta
        if (mysqli_stmt_execute($stmt)) {
            header("Location: usuarios.php?pagina=" . $pagina);
            exit; // Terminar el script después de redireccionar
        } else {
            echo "Error al actualizar los datos del usuario: " . mysqli_error($conexion);
        }

        // Cerrar la declaración y la conexión
        mysqli_stmt_close($stmt);
        mysqli_close($conexion);
    }
}
?>
