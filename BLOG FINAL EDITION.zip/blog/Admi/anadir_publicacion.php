<?php
require("../Datos_conexion/conexion2.php");

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $titulo = $_POST['titulo'];
    $contenido = $_POST['contenido'];
    $estatus = $_POST['estatus'];
    $comentarios = $_POST['comentarios'];

    // Verificar si se subió una nueva imagen
    if ($_FILES['imagen']['size'] > 0) {
        $imagen = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));
    }

    // Obtener el ID del administrador de la cookie
    $id_administrador = $_COOKIE['id_usuario'];

    // Insertar los datos de la nueva publicación en la tabla 'publicaciones'
    $sql_insert_publicacion = "INSERT INTO publicaciones (Titulo, Contenido, Imagen) VALUES ('$titulo', '$contenido', '$imagen')";
    mysqli_query($conexion, $sql_insert_publicacion);

    // Obtener el ID de la publicación recién insertada
    $id_publicacion = mysqli_insert_id($conexion);

    // Insertar datos en la tabla 'publicaciones_datos'
    $sql_insert_datos = "INSERT INTO publicaciones_datos (Estatus, Comentarios_estatus, Id_publicacion, Id_administrador_aprobador, Id_administrador) VALUES ('$estatus', '$comentarios', '$id_publicacion',  '$id_administrador', '$id_administrador')";
    mysqli_query($conexion, $sql_insert_datos);

    // Redireccionar después de la inserción
    header("Location: publicaciones.php");
    exit; // Terminar el script después de redireccionar
}
?>