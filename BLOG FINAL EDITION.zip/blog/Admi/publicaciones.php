<?php
// Verificar si la cookie no está presente
if (!isset($_COOKIE['id_usuario'])) {
    header("Location: ../login_admi/index.php"); // Redireccionar al usuario al formulario de inicio de inicio de sesión
    exit; // Detener la ejecución del resto del código
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Enlace a la hoja de estilos de Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">


    <!-- Otros estilos -->
    <link
        href='https://fonts.googleapis.com/css2?family=Lato:wght@400;700&family=Poppins:wght@400;500;600;700&display=swap'
        rel='stylesheet'>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="style.css">


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

    <!-- Favicon -->
    <link rel="icon" href="mewing.jpg" type="image/x-icon">
    <title>Panel de administración</title>
</head>

<body>
    <?php
    require ("../Datos_conexion/conexion.php");
    // Verificar si la cookie 'id_usuario' está definida y no está vacía
    if (isset($_COOKIE['id_usuario']) && !empty($_COOKIE['id_usuario'])) {
        $id_admi = $_COOKIE['id_usuario'];

        $sql = "SELECT * FROM admi WHERE Id_admi = ?";
        $resultado = $base->prepare($sql);
        $resultado->execute([$id_admi]);

        // Verificar si se encontraron resultados
        if ($resultado->rowCount() > 0) {
            $administrador = $resultado->fetch(PDO::FETCH_ASSOC);
            $contenido = $administrador['Foto'];
        } else {
            echo "No se encontró ningún administrador con ese ID.";
        }
    } else {
        // Redireccionar al usuario al inicio de sesión si la cookie no está definida
        header("Location: ../login_admi/index.php");
        exit; // Terminar la ejecución del script después de redireccionar
    }


    if (isset($_GET["pagina"])) {
        if ($_GET["pagina"] == 1) {
            header("Location:publicaciones.php");
        } else {
            $pagina = $_GET["pagina"];
        }
    } else {
        $pagina = 1;
    }

    $sql_total = "SELECT * FROM publicaciones";
    $resultado_total = $base->query($sql_total);
    $num_filas = $resultado_total->rowCount();

    $tamano_paginas = 5;
    $empezar_desde = ($pagina - 1) * $tamano_paginas;

    $total_paginas = ceil($num_filas / $tamano_paginas);

    $sql_limite = "SELECT p.Id_publicacion, 
    p.Titulo, 
    p.Contenido, 
    p.Imagen, 
    pd.Estatus, 
    pd.Fecha_publicacion, 
    pd.Comentarios_estatus, 
    p.Id_editor, 
    pd.Id_administrador, 
    COALESCE(a.Nombre, 'Desconocido') AS Nombre_administrador
FROM publicaciones p
LEFT JOIN publicaciones_datos pd ON p.Id_publicacion = pd.Id_publicacion
LEFT JOIN admi a ON pd.Id_administrador = a.Id_admi
UNION
SELECT p.Id_publicacion, 
    p.Titulo, 
    p.Contenido, 
    p.Imagen, 
    pd.Estatus, 
    pd.Fecha_publicacion, 
    pd.Comentarios_estatus, 
    p.Id_editor, 
    pd.Id_administrador, 
    COALESCE(a.Nombre, 'Desconocido') AS Nombre_administrador
FROM publicaciones p
RIGHT JOIN publicaciones_datos pd ON p.Id_publicacion = pd.Id_publicacion
LEFT JOIN admi a ON pd.Id_administrador = a.Id_admi";

    $resultado_limite = $base->query($sql_limite);
    $registro = $resultado_limite->fetchAll(PDO::FETCH_OBJ);
    ?>

    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <i class='bx bxs-smile'></i>
            <span class="text">Pobres de Marimar</span>
        </a>
        <ul class="side-menu top">
            <li id="panel">
                <a href="panel.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Panel</span>
                </a>
            </li>
            <li id="blog" class="active">
                <a href="publicaciones.php">
                    <i class='bx bxs-book-content'></i>
                    <span class="text">Publicaciones</span>
                </a>
            </li>
           
            <li id="editors">
                <a href="editores.php">
                    <i class='bx bxs-group'></i>
                    <span class="text">Editores</span>
                </a>
            </li>
            <li id="users">
                <a href="usuarios.php">
                    <i class='bx bxs-user-circle'></i>
                    <span class="text">Usuarios</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="cerrar.sesion.php" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Cerrar sesión</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->

    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <form action="#" class="search-form">
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" class="switch-input" hidden>
            <label for="switch-mode" class="switch-mode">
                <i class="bx bx-sun"></i>
                <i class="bx bx-moon"></i>
            </label>
            <a href="#" class="profile">
                <?php echo "<img src='data:image/jpeg;base64," . base64_encode($contenido) . "' alt='Foto de perfil del administrador'>" ?>
            </a>
        </nav>
        <!-- NAVBAR -->

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <a href="generar.html" class="btn-download">
                    <i class='bx bxs-cloud-download'></i>
                    <span class="text">Generar PDF</span>
                </a>
            </div>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Publicaciones</h3>
                        <i class='bx bx-search'></i>
                        <i class='bx bx-filter'></i>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Titulo</th>
                                <th>Contenido</th>
                                <th>Editor</th>
                                <th>Estatus</th>
                                <th>Fecha de publicacion</th>
                                <th>
                                    <a href="#" class="add-record" data-target="#modalAñadirUsuario">
                                        <i class="bi bi-plus-lg"></i>
                                    </a>
                                </th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($registro as $publicacion): ?>
                                <tr>
                                    <td>
                                        <?php echo $publicacion->Id_publicacion; ?>
                                    </td>
                                    <td>
                                        <?php echo $publicacion->Titulo; ?>
                                    </td>
                                    <td>
                                        <?php echo $publicacion->Contenido; ?>
                                    </td>
                                    <td>
                                        <img src="data:image/jpeg;base64,<?php echo base64_encode($publicacion->Imagen); ?>"
                                            alt="Imagen de la publicación">
                                    </td>
                                    <td>
                                        <?php
                                        if ($publicacion->Id_editor == null) {
                                            echo $publicacion->Nombre_administrador . " <i>(Admi)</i>";
                                        } else {
                                            // Consulta para obtener el nombre del editor
                                            $sql_editor = "SELECT Nombre FROM editores WHERE Id_editor = ?";
                                            $stmt_editor = $base->prepare($sql_editor);
                                            $stmt_editor->execute([$publicacion->Id_editor]);
                                            $editor = $stmt_editor->fetch(PDO::FETCH_ASSOC);
                                            if ($editor) {
                                                echo $editor['Nombre'];
                                            } else {
                                                echo 'Desconocido';
                                            }
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php echo $publicacion->Estatus; ?>
                                    </td>
                                    <td>
                                        <?php echo date("d/m/Y", strtotime($publicacion->Fecha_publicacion)); ?>
                                    </td>
                                </tr>
                                </td>
                                <td>
                                    <a href="#" class="edit-record"
                                        data-publicaciones-id="<?php echo $publicacion->Id_Publicacion; ?>"
                                        data-publicaciones-titulo="<?php echo $publicacion->Titulo; ?>"
                                        data-publicaciones-contenido="<?php echo $publicacion->Contenido; ?>"
                                        data-publicaciones-imagen="<?php echo base64_encode($publicacion->Imagen); ?>"
                                        data-publicaciones-editor="<?php echo $publicacion->Editor; ?>"
                                        data-publicaciones-estatus="<?php echo $publicacion->Estatus; ?>"
                                        data-publicaciones-comentarios="<?php echo $publicacion->Comentarios_estatus; ?>"
                                        data-publicaciones-fecha="<?php echo $publicacion->Fecha_publicacion; ?>"
                                        data-toggle="modal" data-target="#Editar">
                                        <i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i>
                                    </a>

                                </td>
                                <td>
                                    <a href="#" class="delete-record"
                                        data-usuario-id="<?php echo $publicacion->Id_publicacion; ?>" data-toggle="modal"
                                        data-target="#Eliminar">
                                        <i class="bx bx-trash" style="font-size: calc(1em + 5px); color: grey;"></i>
                                    </a>
                                </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="pagination">
                 <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                  <li class="page-item <?php echo ($i == $pagina) ? 'active' : ''; ?>">
                  <a href="?pagina=<?php echo $i; ?>" class="page-link"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>
    </div>
        </main>
    </section>
    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modalEliminar">Eliminar</button>

    <!-- Modal para eliminar -->
    <div class="modal fade" id="Eliminar" tabindex="-1" role="dialog" aria-labelledby="EliminarLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEliminarLabel">Confirmar eliminación</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    ¿Estás seguro de que deseas eliminar esta publicación?
                </div>
                <div class="modal-footer">
                    <!-- Agrega aquí el formulario de eliminación -->
                    <form action="eliminar_publicacion.php" method="POST">
                        <input type="hidden" id="id_publicacion_eliminar" name="id_publicacion_eliminar"
                            value="<?php echo $publicacion->Id_Publicacion; ?>">
                        <input type="hidden" name="pagina" value="<?php echo $pagina; ?>">
                        <!-- Botón para cancelar -->
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Confirmar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Ventana Modal para editar publicaciones -->
    <div class="modal fade" id="Editar" tabindex="-1" role="dialog" aria-labelledby="EditarLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="EditarLabel">Editar Publicaciones</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Formulario de edición -->
                    <form id="editarForm" action="editar_publicacion.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="titulo">Título:</label>
                            <input type="text" class="form-control" id="titulo" name="titulo" required>
                        </div>
                        <div class="form-group">
                            <label for="contenido">Contenido:</label>
                            <textarea class="form-control" id="contenido" name="contenido" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="estatus">Estatus:</label>
                            <select name="estatus" class="form-control">
                                <option value="Pendiente">--</option>
                                <option value="Aprobada">Aprobada</option>
                                <option value="Rechazada">Rechazada</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comentarios">Comentarios del estatus:</label>
                            <input type="text" class="form-control" id="comentarios" name="comentarios">
                        </div>
                        <div class="form-group">
                            <label for="foto">Cambiar Imagen:</label>
                            <input type="file" name="foto" class="form-control-file">
                        </div>
                        <!-- Campo oculto para el ID de la publicación a editar -->
                        <input type="hidden" id="id_publicacion_editar" name="id_publicacion_editar">
                        <input type="hidden" name="pagina" value="<?php echo $pagina; ?>">
                        <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    </form>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Ventana Modal para añadir publicaciones -->
    <div class="modal fade" id="modalAñadirPublicacion" tabindex="-1" role="dialog"
        aria-labelledby="modalAñadirPublicacionLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalAñadirPublicacionLabel">Añadir Publicación</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Formulario de añadir publicación -->
                    <form id="añadirForm" action="anadir_publicacion.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="titulo">Título:</label>
                            <input type="text" class="form-control" id="titulo" name="titulo" required>
                        </div>
                        <div class="form-group">
                            <label for="contenido">Contenido:</label>
                            <textarea class="form-control" id="contenido" name="contenido" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="estatus">Estatus:</label>
                            <select name="estatus" class="form-control">
                                <option value="Pendiente">--</option>
                                <option value="Aprobada">Aprobada</option>
                                <option value="Rechazada">Rechazada</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comentarios">Comentarios del estatus:</label>
                            <input type="text" class="form-control" id="comentarios" name="comentarios">
                        </div>
                        <div class="form-group">
                            <label for="imagen">Imagen:</label>
                            <input type="file" name="imagen" class="form-control-file">
                        </div>
                        <input type="hidden" name="pagina" value="<?php echo $pagina; ?>">
                        <button type="submit" class="btn btn-primary">Añadir Publicación</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
        $(document).ready(function () {
            $('.edit-record').click(function () {
                var idPublicacion = $(this).data('publicaciones-id');
                var tituloPublicacion = $(this).data('publicaciones-titulo');
                var contenidoPublicacion = $(this).data('publicaciones-contenido');
                var estatusPublicacion = $(this).data('publicaciones-estatus');
                var comentariosPublicacion = $(this).data('publicaciones-comentarios');
                var editorPublicacion = $(this).data('publicaciones-editor');
                var fechaPublicacion = $(this).data('publicaciones-fecha');

                // Asigna los valores a los campos del formulario de edición
                $('#id_publicacion_editar').val(idPublicacion);
                $('#titulo').val(tituloPublicacion);
                $('#contenido').val(contenidoPublicacion);
                $('#estatus').val(estatusPublicacion);
                $('#comentarios').val(comentariosPublicacion);
                // Faltaba asignar el valor al campo 'editor'
                $('#editor').val(editorPublicacion);

                $('#Editar').modal('show');  // Muestra la ventana modal de edición
            });
        });


    </script>

    <script>
        $(document).ready(function () {
            $('.add-record').click(function () {
                console.log('Clic en el botón de añadir publicaciones');
                $('#modalAñadirPublicacion').modal('show');
            });
        });
    </script>

    <!-- Importar jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Importar Popper.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <!-- Importar Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>

</html>