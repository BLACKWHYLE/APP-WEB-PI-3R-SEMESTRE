const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');

allSideMenu.forEach(item=> {
	const li = item.parentElement;

	item.addEventListener('click', function () {
		allSideMenu.forEach(i=> {
			i.parentElement.classList.remove('active');
		})
		li.classList.add('active');
	})
});

// TOGGLE SIDEBAR
const menuBar = document.querySelector('#content nav .bx.bx-menu');
const sidebar = document.getElementById('sidebar');

menuBar.addEventListener('click', function () {
	sidebar.classList.toggle('hide');
})

const searchButton = document.querySelector('#content nav form .form-input button');
const searchButtonIcon = document.querySelector('#content nav form .form-input button .bx');
const searchForm = document.querySelector('#content nav form');

searchButton.addEventListener('click', function (e) {
	if(window.innerWidth < 576) {
		e.preventDefault();
		searchForm.classList.toggle('show');
		if(searchForm.classList.contains('show')) {
			searchButtonIcon.classList.replace('bx-search', 'bx-x');
		} else {
			searchButtonIcon.classList.replace('bx-x', 'bx-search');
		}
	}
})


if(window.innerWidth < 768) {
	sidebar.classList.add('hide');
} else if(window.innerWidth > 576) {
	searchButtonIcon.classList.replace('bx-x', 'bx-search');
	searchForm.classList.remove('show');
}


window.addEventListener('resize', function () {
	if(this.innerWidth > 576) {
		searchButtonIcon.classList.replace('bx-x', 'bx-search');
		searchForm.classList.remove('show');
	}
})

document.addEventListener("DOMContentLoaded", function() {
    const switchMode = document.getElementById('switch-mode');

    function aplicarModoOscuro() {
        document.body.classList.add('dark');
        switchMode.checked = true;
        localStorage.setItem('modoOscuro', 'activado'); // Guardar estado en localStorage
    }

    function quitarModoOscuro() {
        document.body.classList.remove('dark');
        switchMode.checked = false;
        localStorage.setItem('modoOscuro', 'desactivado'); // Guardar estado en localStorage
    }

    // Verificar si el modo oscuro está activado en localStorage al cargar la página
    const modoOscuroGuardado = localStorage.getItem('modoOscuro');
    if (modoOscuroGuardado === 'activado') {
        aplicarModoOscuro();
    }

    // Evento para cambiar el estado del modo oscuro al hacer clic en el interruptor
    switchMode.addEventListener('change', function () {
        if (this.checked) {
            aplicarModoOscuro();
        } else {
            quitarModoOscuro();
        }
    });
});



const notificationContainer = document.querySelector('.notification-container');
const notificationDropdown = document.querySelector('.notification-dropdown');

const notifications = [
    { title: "Notificacion 1", content: "Sin contenido" },
    { title: "Notificacion 2", content: "Sin contenido" },
    { title: "Notificacion 3", content: "Sin contenido" }
];

function showNotifications() {
    notificationDropdown.innerHTML = '';

    notifications.forEach(notification => {
        const notificationElement = document.createElement('div');
        notificationElement.classList.add('notification-item');
        notificationElement.innerHTML = `
            <h3>${notification.title}</h3>
            <p>${notification.content}</p>
        `;
        notificationDropdown.appendChild(notificationElement);
    });

 
    if (notificationDropdown.style.display === 'block') {
        notificationDropdown.style.animation = 'fadeOut 0.4s ease forwards'; 
        setTimeout(() => {
            notificationDropdown.style.display = 'none';
        }, 500);
    } else {
        notificationDropdown.style.display = 'block';
        notificationDropdown.style.animation = 'fadeIn 0.4s ease forwards';
    }
}

notificationContainer.addEventListener('click', function (event) {
    event.stopPropagation(); 
    showNotifications();
});

document.addEventListener('click', function (event) {
    
    if (!notificationContainer.contains(event.target)) {
        if (notificationDropdown.style.display === 'block') {
            notificationDropdown.style.animation = 'fadeOut 0.3s ease forwards'; 
            setTimeout(() => {
                notificationDropdown.style.display = 'none';
            }, 500); 
        }
    }
});

