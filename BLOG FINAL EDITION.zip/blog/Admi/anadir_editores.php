<?php
require("../Datos_conexion/conexion2.php");

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $nombre = $_POST['nombre'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $genero = $_POST['genero'];
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];
    $pagina = $_POST['pagina'];

    // Verificar si se subió una nueva imagen
    if ($_FILES['foto']['size'] > 0) {
        $foto = addslashes(file_get_contents($_FILES['foto']['tmp_name']));
    }

    // Cifrar la contraseña antes de almacenarla en la base de datos
    $contrasena_cifrada = password_hash($contrasena, PASSWORD_DEFAULT);

    // Insertar los datos del nuevo editor en la tabla 'editores'
    $sql_insert_editor = "INSERT INTO editores (Nombre, Foto, Fecha_nacimiento, Genero, Correo, Contrasena) VALUES ('$nombre', '$foto', '$fecha_nacimiento', '$genero', '$correo', '$contrasena_cifrada')";
    
    if (mysqli_query($conexion, $sql_insert_editor)) {
        // Obtener el ID del editor recién insertado
        $id_editor = mysqli_insert_id($conexion);

        // Insertar datos en la tabla 'editores_datos'
        $token = "abcd1234";
        $codigo = 1234;
        $sql_insert_datos = "INSERT INTO editores_datos (Token, Codigo, Id_editor) VALUES ('$token', $codigo, $id_editor)";

        if (mysqli_query($conexion, $sql_insert_datos)) {
            header("Location: editores.php?pagina=" . $pagina);
            exit; // Terminar el script después de redireccionar
        } else {
            echo "Error al insertar datos de registro del editor: " . mysqli_error($conexion);
        }
    } else {
        echo "Error al insertar los datos del editor: " . mysqli_error($conexion);
    }
}

?>