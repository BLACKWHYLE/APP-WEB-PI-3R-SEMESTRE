<?php
require_once 'dompdf/autoload.inc.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Conexión a la base de datos (modifica estos valores según tu configuración)
$servername = "localhost";
$username = "usuario";
$password = "contraseña";
$dbname = "nombre_base_de_datos";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta SQL para obtener los datos de la tabla editores
$sql = "SELECT Id_editor, nombre, foto, fecha_nacimiento, genero, correo FROM editores";
$resultado = $conn->query($sql);

// Verificar si se encontraron resultados
if ($resultado->num_rows > 0) {
    // Inicializar el contenido HTML del PDF
    $html = '
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Datos de editores</title>
    </head>
    <body>
        <h1>Datos de editores</h1>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Foto</th>
                <th>Fecha de Nacimiento</th>
                <th>Género</th>
                <th>Correo</th>
            </tr>';

    // Iterar sobre los resultados de la consulta y agregarlos al contenido HTML del PDF
    while ($fila = $resultado->fetch_assoc()) {
        $html .= '<tr>
                    <td>' . $fila['Id_editor'] . '</td>
                    <td>' . $fila['nombre'] . '</td>
                    <td><img src="' . $fila['foto'] . '" width="100"></td>
                    <td>' . $fila['fecha_nacimiento'] . '</td>
                    <td>' . $fila['genero'] . '</td>
                    <td>' . $fila['correo'] . '</td>
                  </tr>';
    }

    // Cerrar la tabla y el documento HTML
    $html .= '
        </table>
    </body>
    </html>';

    // Liberar resultado
    $resultado->free();

    // Cerrar conexión
    $conn->close();

    // Generar PDF
    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $pdf = new Dompdf($options);
    $pdf->loadHtml($html);
    $pdf->setPaper('A4', 'portrait');
    $pdf->render();
    $pdf->stream('editores.pdf', array('Attachment' => 0));
} else {
    echo "No se encontraron editores en la base de datos.";
}

?>
