<script src="script.js"></script>
<?php 
    // Incluye el archivo de conexión a la base de datos
    include("../Datos_conexion/conexion.php");

    // Consulta SQL para obtener los títulos y fechas de publicación de las nuevas publicaciones pendientes
    $sqlNewPublications = "SELECT publicaciones.Titulo, DATE_FORMAT(publicaciones_datos.Fecha_publicacion, '%Y-%m-%d') AS Fecha_publicacion
                           FROM publicaciones
                           INNER JOIN publicaciones_datos ON publicaciones.Id_publicacion = publicaciones_datos.Id_publicacion
                           WHERE publicaciones_datos.Fecha_publicacion >= DATE_SUB(NOW(), INTERVAL 1 DAY) 
                           AND publicaciones_datos.Estatus = 'pendiente'";
    $result = $base->query($sqlNewPublications);
    $notifications = $result->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="notification-container">
    <a href="#" class="notification">
        <i class="bx bxs-bell"></i>
        <span class="num"><?php echo count($notifications); ?></span> <!-- Mostrar el número de nuevas publicaciones -->
    </a>
    <div class="notification-dropdown"></div>
</div>

<script>
    const notificationContainer = document.querySelector('.notification-container');
    const notificationDropdown = document.querySelector('.notification-dropdown');

    const notifications = <?php echo json_encode($notifications); ?>;

    function showNotifications() {
        notificationDropdown.innerHTML = '';
        notificationDropdown.style.position = 'fixed';

        notifications.forEach(notification => {
            const notificationElement = document.createElement('div');
            notificationElement.classList.add('notification-item');
            notificationElement.innerHTML = `
                <h3>${notification.Titulo}</h3>
                <p>${notification.Fecha_publicacion}</p>
            `;
            notificationDropdown.appendChild(notificationElement);
        });

        if (notificationDropdown.style.display === 'block') {
            notificationDropdown.style.animation = 'fadeOut 0.4s ease forwards'; 
            setTimeout(() => {
                notificationDropdown.style.display = 'none';
            }, 500);
        } else {
            notificationDropdown.style.display = 'block';
            notificationDropdown.style.animation = 'fadeIn 0.4s ease forwards';
        }
    }

    notificationContainer.addEventListener('click', function (event) {
        event.stopPropagation(); 
        showNotifications();
    });

    document.addEventListener('click', function (event) {
        if (!notificationContainer.contains(event.target)) {
            if (notificationDropdown.style.display === 'block') {
                notificationDropdown.style.animation = 'fadeOut 0.3s ease forwards'; 
                setTimeout(() => {
                    notificationDropdown.style.display = 'none';
                }, 500); 
            }
        }
    });

    document.addEventListener('DOMContentLoaded', function() {
        const notificationClicked = getCookie('notificationClicked');
        if (notificationClicked) {
            // Si la cookie está presente, oculta el número y elimina la clase 'notification'
            const numSpan = document.querySelector('.num');
            numSpan.textContent = '';
            const notification = document.querySelector('.notification');
            notification.classList.remove('notification');
        }
    });

    // Selecciona el enlace de notificación
    const notificationLink = document.querySelector('.notification');

    // Agrega un controlador de eventos clic al enlace de notificación
    notificationLink.addEventListener('click', function(event) {
        // Selecciona el elemento <span> dentro del enlace y elimina su contenido
        const numSpan = this.querySelector('.num');
        numSpan.textContent = ''; // Elimina el contenido del elemento <span>

        // Establece una cookie para indicar que se ha hecho clic en la campana
        setCookie('notificationClicked', true, 365); // La cookie expira en 365 días

        // Elimina la clase 'notification' del enlace para que el punto rojo desaparezca
        this.classList.remove('notification');

        // Previene el comportamiento predeterminado del enlace (evita cambiar de página)
        event.preventDefault();
    });

    // Función para establecer una cookie
    function setCookie(name, value, days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        const expires = "expires=" + date.toUTCString();
        document.cookie = name + "=" + value + ";" + expires + ";path=/";
    }

    // Función para obtener el valor de una cookie
    function getCookie(name) {
        const cookieName = name + "=";
        const cookies = decodeURIComponent(document.cookie).split(';');
        for (let i = 0; i < cookies.length; i++) {
            let cookie = cookies[i].trim();
            if (cookie.indexOf(cookieName) === 0) {
                return cookie.substring(cookieName.length, cookie.length);
            }
        }
        return null;
    }
</script>