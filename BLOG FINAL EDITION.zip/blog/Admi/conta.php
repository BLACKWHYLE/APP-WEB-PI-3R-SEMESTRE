<?php
// Incluir el archivo de conexión a la base de datos
require_once '../Datos_conexion/conexion2.php';

// Recuperar el ID del usuario y la nueva contraseña cifrada
$id_usuario = 2; // Aquí debes proporcionar el ID del usuario que deseas actualizar
$nueva_contrasena = password_hash("123", PASSWORD_DEFAULT);

// Construir la consulta SQL
$sql = "UPDATE admi SET Contrasena = '$nueva_contrasena' WHERE Id_admi = $id_usuario";

// Ejecutar la consulta
if ($conexion->query($sql) === TRUE) {
    echo "Contraseña actualizada correctamente.";
} else {
    echo "Error al actualizar la contraseña: " . $conexion->error;
}
?>
