<?php
require("../Datos_conexion/conexion2.php");

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $nombre = $_POST['nombre'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $genero = $_POST['genero'];
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];
    $pagina = $_POST['pagina'];

    // Hash de la contraseña
    $contrasena = password_hash($contrasena, PASSWORD_DEFAULT);

    // Verificar si se subió una nueva imagen
    if ($_FILES['foto']['size'] > 0) {
        $foto = file_get_contents($_FILES['foto']['tmp_name']);
        
        // Escapar los datos para prevenir inyección de SQL (opcional dependiendo del origen de los datos)
        $nombre = mysqli_real_escape_string($conexion, $nombre);
        $fecha_nacimiento = mysqli_real_escape_string($conexion, $fecha_nacimiento);
        $genero = mysqli_real_escape_string($conexion, $genero);
        $correo = mysqli_real_escape_string($conexion, $correo);
        $contrasena = mysqli_real_escape_string($conexion, $contrasena);

        // Insertar los datos del usuario en la base de datos
        $sql = "INSERT INTO usuarios (Nombre, Fecha_Nacimiento, Genero, Correo, Contrasena, Foto) VALUES ('$nombre', '$fecha_nacimiento', '$genero', '$correo', '$contrasena', ?)";

        // Preparar la consulta con la imagen
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "s", $foto);

        // Ejecutar la consulta
        if (mysqli_stmt_execute($stmt)) {
            // Obtener el ID del usuario recién insertado
            $id_usuario = mysqli_insert_id($conexion);

            // Insertar datos en la tabla usuarios_datos_registro
            $sql_registro = "INSERT INTO usuarios_datos_registro (Token, Codigo, Id_usuario) VALUES ('abcd1234', 1234, $id_usuario)";
            mysqli_query($conexion, $sql_registro);

            header("Location: usuarios.php?pagina=" . $pagina);
            exit; // Terminar el script después de redireccionar
        } else {
            echo "Error al insertar los datos del usuario: " . mysqli_error($conexion);
        }

        // Cerrar la declaración y la conexión
        mysqli_stmt_close($stmt);
        mysqli_close($conexion);
    } else {
        echo "Por favor, seleccione una imagen.";
    }
}
?>