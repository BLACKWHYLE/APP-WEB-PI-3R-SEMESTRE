<?php
require ("../Datos_conexion/conexion.php");

// Recuperar el ID de la publicación a eliminar
$id_publicacion = $_POST['id_publicacion_eliminar'];
$pagina = $_POST['pagina'];

// Preparar la consulta SQL para eliminar la publicación de la tabla "publicaciones_datos"
$sql = "DELETE publicaciones, publicaciones_datos FROM publicaciones
                                LEFT JOIN publicaciones_datos ON publicaciones.Id_publicacion = publicaciones_datos.Id_publicacion
                                WHERE publicaciones.Id_publicacion = :id_publicacion";

// Preparar la sentencia para eliminar los datos relacionados
$resultado = $base->prepare($sql);
$resultado->execute(array(":id_publicacion" => $id_publicacion));

// Redireccionar a la página de las publicaciones después de eliminar
header("Location: publicaciones.php?pagina=" . $pagina);
?>