<?php
// Verifica si hay un parámetro 'correo' en la URL
if(isset($_GET['correo'])) {
    // Obtiene el valor del parámetro 'correo' de la URL
    $valor_cookie = $_GET['correo'];

    // Establece la cookie 'user_email' con el valor obtenido
    setcookie("user_email", $valor_cookie, time() + 900);

    echo "Cookie 'user_email' creada correctamente con el valor: " . $valor_cookie;
    echo $_COOKIE['user_email'];
    header("Location:panel.php");
} else {
    echo "No se proporcionó ningún valor de correo electrónico en la URL.";
}
?>