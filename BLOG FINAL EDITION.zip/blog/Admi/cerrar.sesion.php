<?php
// Verificar si hay una cookie de sesión válida
if(isset($_COOKIE['id_usuario'])) {
    // Destruir la cookie estableciendo su tiempo de expiración en el pasado
    setcookie('id_usuario', '', time() - 3600, '/');
    
    // Redirigir al usuario al formulario de inicio de sesión u otra página
    header('Location: ../index.php');
    exit; // Finalizar el script después de redirigir
} else {
    // Si no hay una cookie de sesión válida, simplemente redirigir al usuario al formulario de inicio de sesión
    header('Location: ../index.php');
    exit; // Finalizar el script después de redirigir
}
?>
