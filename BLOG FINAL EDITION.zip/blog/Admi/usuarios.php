<?php
// Verificar si la cookie no está presente
if (!isset($_COOKIE['id_usuario'])) {
    header("Location: ../login_admi/index.php"); // Redireccionar al usuario al formulario de inicio de inicio de sesión
    exit; // Detener la ejecución del resto del código
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Enlace a la hoja de estilos de Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">


    <!-- Otros estilos -->
    <link
        href='https://fonts.googleapis.com/css2?family=Lato:wght@400;700&family=Poppins:wght@400;500;600;700&display=swap'
        rel='stylesheet'>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="style.css">


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <!-- Favicon -->
    <link rel="icon" href="mewing.jpg" type="image/x-icon">
    <title>Panel de administración</title>
</head>

<body>
    <?php
    require ("../Datos_conexion/conexion.php");

    // Verificar si la cookie 'id_usuario' está definida y no está vacía
    if (isset($_COOKIE['id_usuario']) && !empty($_COOKIE['id_usuario'])) {
        $id_admi = $_COOKIE['id_usuario'];

        $sql = "SELECT * FROM admi WHERE Id_admi = ?";
        $resultado = $base->prepare($sql);
        $resultado->execute([$id_admi]);

        // Verificar si se encontraron resultados
        if ($resultado->rowCount() > 0) {
            $administrador = $resultado->fetch(PDO::FETCH_ASSOC);
            $contenido = $administrador['Foto'];
        } else {
            echo "No se encontró ningún administrador con ese ID.";
        }
    } else {
        // Redireccionar al usuario al inicio de sesión si la cookie no está definida
        header("Location: ../login_admi/index.php");
        exit; // Terminar la ejecución del script después de redireccionar
    }

    if (isset($_GET["pagina"])) {
        if ($_GET["pagina"] == 1) {
            header("Location:usuarios.php");
        } else {
            $pagina = $_GET["pagina"];
        }
    } else {
        $pagina = 1;
    }

    $sql_total = "SELECT * FROM usuarios";
    $resultado = $base->prepare($sql_total);
    $resultado->execute(array());

    $num_filas = $resultado->rowCount();

    $tamano_paginas = 5;

    $empezar_desde = ($pagina - 1) * $tamano_paginas;

    $total_paginas = ceil($num_filas / $tamano_paginas);

    $resultado->closeCursor();

    $sql_limite = "SELECT * FROM usuarios LIMIT $empezar_desde, $tamano_paginas";

    $resultado = $base->prepare($sql_limite);
    $resultado->execute();

    $registro = $base->query(
        "SELECT usuarios.*, YEAR(CURDATE()) - YEAR(Fecha_Nacimiento) AS Edad,
    DATE(usuarios_datos_registro.Fecha_registro) AS Fecha_registro
    FROM usuarios
    INNER JOIN usuarios_datos_registro
    ON usuarios.Id_usuario = usuarios_datos_registro.Id_usuario
    LIMIT $empezar_desde, $tamano_paginas"
    )->fetchAll(PDO::FETCH_OBJ); ?>

    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <i class='bx bxs-smile'></i>
            <span class="text">Pobres de Marimar</span>
        </a>
        <ul class="side-menu top">
            <li id="panel">
                <a href="panel.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Panel</span>
                </a>
            </li>
            <li id="blog">
                <a href="publicaciones.php">
                    <i class='bx bxs-book-content'></i>
                    <span class="text">Publicaciones</span>
                </a>
            </li>
            <li id="editors">
                <a href="editores.php">
                    <i class='bx bxs-group'></i>
                    <span class="text">Editores</span>
                </a>
            </li>
            <li id="users" class="active">
                <a href="usuarios.php">
                    <i class='bx bxs-user-circle'></i>
                    <span class="text">Usuarios</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="cerrar.sesion.php" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Cerrar sesión</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->

    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <form action="#" class="search-form">
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Buscar..." name="campo" id="campo">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" class="switch-input" hidden>
            <label for="switch-mode" class="switch-mode">
                <i class="bx bx-sun"></i>
                <i class="bx bx-moon"></i>
            </label>
            <a href="#" class="profile">
                <?php echo "<img src='data:image/jpeg;base64," . base64_encode($contenido) . "' alt='Foto de perfil del administrador'>" ?>
            </a>
        </nav>
        <!-- NAVBAR -->

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <a href="generar.html" class="btn-download">
                    <i class='bx bxs-cloud-download'></i>
                    <span class="text">Generar PDF</span>
                </a>
            </div>

            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Usuarios Registrados</h3>
                        <i class='bx bx-search'></i>
                        <i class='bx bx-filter'></i>
                    </div>
                    <table id="tabla">
                        <thead>
                            <tr>
                                <th>ID Usuario</th>
                                <th>Nombre</th>
                                <th>Edad</th>
                                <th>Genero</th>
                                <th>Fecha de Registro</th>
                                <th>Correo</th>
                                <th>
                                    <a href="#" class="add-record" data-target="#modalAñadirUsuario">
                                        <span class="material-icons" data-toggle="tooltip"
                                            title="Add">person_add_alt</span>
                                    </a>
                                </th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($registro as $usuario): ?>
                                <tr>
                                    <td>
                                        <p>
                                            <?php echo $usuario->Id_usuario; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <img src="data:image/jpeg;base64,<?php echo base64_encode($usuario->Foto); ?>"
                                            alt="Foto de perfil del usuario">
                                        <p>
                                            <?php echo $usuario->Nombre; ?>
                                        </p>
                                    </td>

                                    <td>
                                        <p>
                                            <?php echo ($usuario->Edad >= 1) ? $usuario->Edad . " años" : $usuario->Edad * 365 . " días"; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo $usuario->Genero; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo $usuario->Fecha_registro; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo $usuario->Correo; ?>
                                        </p>
                                    </td>
                                    <td>
                                        <?php
                                        $fecha_nacimiento = $usuario->Fecha_Nacimiento;
                                        $fecha_formateada = date("d-m-Y", strtotime($fecha_nacimiento));
                                        ?>
                                        <a href="#" class="edit-record"
                                            data-usuario-id="<?php echo $usuario->Id_usuario; ?>"
                                            data-usuario-nombre="<?php echo $usuario->Nombre; ?>"
                                            data-usuario-fecha="<?php echo $usuario->Fecha_Nacimiento; ?>"
                                            data-usuario-genero="<?php echo $usuario->Genero ?>"
                                            data-usuario-correo="<?php echo $usuario->Correo ?>" data-target="#Editar">
                                            <i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i>
                                        </a>
                                    </td>
                                    </td>
                                    <td>
                                        <a href="#" class="delete-record"
                                            data-usuario-id="<?php echo $usuario->Id_usuario; ?>" data-toggle="modal"
                                            data-target="#Eliminar">
                                            <i class="bx bx-trash" style="font-size: calc(1em + 5px); color: grey;"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="pagination">
                 <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                  <li class="page-item <?php echo ($i == $pagina) ? 'active' : ''; ?>">
                  <a href="?pagina=<?php echo $i; ?>" class="page-link"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>
    </div>
        </main>
    </section>
    <!-- Ventana Modal para eliminar registro -->
    <div class="modal fade" id="Eliminar" tabindex="-1" role="dialog" aria-labelledby="EliminarLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="EliminarLabel">Confirmar eliminación</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    ¿Estás seguro de que quieres eliminar este registro?
                </div>
                <div class="modal-footer">
                    <td>
                        <a href="#" class="delete-record" data-usuario-id="<?php echo $usuario->Id_usuario; ?>"
                            data-toggle="modal" data-target="#Eliminar">
                            <i class="bx bx-trash" style="font-size: calc(1em + 5px); color: grey;"></i>
                        </a>
                    </td>

                    <div class="modal-footer">
                        <!-- Botón para eliminar el registro -->
                        <form action="eliminar_usuario.php" method="POST">
                            <input type="hidden" id="id_usuario_eliminar" name="id_usuario_eliminar" value="">
                            <input type="hidden" name="pagina" value="<?php echo $pagina; ?>">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Eliminar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="Editar" tabindex="-1" role="dialog" aria-labelledby="EditarLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="EditarLabel">Editar usuario</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Formulario de edición -->
                    <form id="editarForm" action="editar_usuario.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="nombre">Nombre:</label>
                            <input type="text" class="form-control" id="nombre" name="nombre"
                                value="<?php echo $row['Nombre']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                            <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento"
                                value="<?php echo $row['Fecha_Nacimiento']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="genero">Género:</label>
                            <input type="text" class="form-control" id="genero" name="genero"
                                value="<?php echo $row['Genero']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="correo">Correo:</label>
                            <input type="email" class="form-control" id="correo" name="correo" required>
                        </div>
                        <div class="form-group">
                            <label for="contrasena">Contraseña:</label>
                            <input type="password" placeholder="Sin cambios" class="form-control" id="contrasena"
                                name="contrasena">
                        </div>
                        <br>
                        <!-- Permitir al usuario cargar una nueva imagen -->
                        Cambiar Foto: <input type="file" name="foto"><br>
                        <!-- Campo oculto para el ID del usuario a editar -->
                        <input type="hidden" id="id_usuario_editar" name="id_usuario_editar"
                            value="<?php echo $id_usuario; ?>">
                        <input type="hidden" name="pagina" value="<?php echo $pagina; ?>">
                        <!-- Botones -->
                        <div class="text-right mt-3">
                            <!-- Botón Guardar cambios -->
                            <button type="submit" class="btn btn-primary">Guardar cambios</button>
                            <!-- Botón Cancelar -->
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Ventana Modal para añadir nuevo usuario -->
    <div class="modal fade" id="modalAñadirUsuario" tabindex="-1" role="dialog"
        aria-labelledby="modalAñadirUsuarioLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalAñadirUsuarioLabel">Añadir Nuevo Usuario</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Formulario para añadir nuevos usuarios -->
                    <form id="añadirForm" action="anadir_usuario.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="nombre">Nombre:</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" required>
                        </div>
                        <div class="form-group">
                            <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                            <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento"
                                required>
                        </div>
                        <div class="form-group">
                            <label for="genero">Género:</label>
                            <input type="text" class="form-control" id="genero" name="genero" required>
                        </div>
                        <div class="form-group">
                            <label for="correo">Correo:</label>
                            <input type="email" class="form-control" id="correo" name="correo" required>
                        </div>
                        <div class="form-group">
                            <label for="contrasena">Contraseña:</label>
                            <input type="password" class="form-control" id="contrasena" name="contrasena" required>
                        </div>
                        <div class="form-group">
                            <label for="foto">Foto:</label>
                            <input type="file" class="form-control" id="foto" name="foto" accept="image/*">
                        </div>
                        <input type="hidden" name="pagina" value="<?php echo $pagina; ?>">
                    </form>
                </div>
                <div class="modal-footer">
                    <!-- Botón para cancelar -->
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <!-- Botón para enviar el formulario -->
                    <button type="submit" class="btn btn-primary" form="añadirForm">Añadir Usuario</button>
                </div>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
        $(document).ready(function () {
            $('.delete-record').click(function () {
                var idUsuario = $(this).data('usuario-id');
                $('#id_usuario_eliminar').val(idUsuario);  // Set the ID to the hidden input field
                $('#Eliminar').modal('show');
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            $('.edit-record').click(function () {
                var idUsuario = $(this).data('usuario-id');
                var nombreUsuario = $(this).data('usuario-nombre');
                var edadUsuario = $(this).data('usuario-edad');
                var generoUsuario = $(this).data('usuario-genero');
                var fechaNacimientoUsuario = $(this).data('usuario-fecha'); // Suponiendo que esta variable contiene la fecha de nacimiento
                var correoUsuario = $(this).data('usuario-correo');

                // Asigna los valores a los campos del formulario de edición
                $('#id_usuario_editar').val(idUsuario);
                $('#nombre').val(nombreUsuario);
                $('#edad').val(edadUsuario);
                $('#genero').val(generoUsuario);
                $('#fecha_nacimiento').val(fechaNacimientoUsuario); // Asigna la fecha de nacimiento al campo correspondiente
                $('#correo').val(correoUsuario);
                $('#Editar').modal('show');  // Muestra la ventana modal de edición
            });
        });
    </script>




    <script>
        $(document).ready(function () {
            $('.add-record').click(function () {
                console.log('Clic en el botón de añadir usuario');
                $('#modalAñadirUsuario').modal('show');
            });
        });
    </script>

    <!-- Importar jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Importar Popper.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <!-- Importar Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>

</html>