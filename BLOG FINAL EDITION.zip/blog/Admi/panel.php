<?php
// Verificar si la cookie no está presente
if (!isset($_COOKIE['id_usuario'])) {
    header("Location: ../login_admi/index.php"); // Redireccionar al usuario al formulario de inicio de inicio de sesión
    exit; // Detener la ejecución del resto del código
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <!-- My CSS -->
    <link rel="stylesheet" href="style.css">

    <!-- favicon -->
    <link rel="icon" href="mewing.jpg" type="image/x-icon">

    <title>Panel de administración</title>
</head>

<body>
    <?php
    require ("../Datos_conexion/conexion.php");

    $sqlCountNewPublications = "SELECT COUNT(*) AS nuevas FROM publicaciones_datos WHERE Fecha_publicacion >= DATE_SUB(NOW(), INTERVAL 3 DAY)";
    $resultCount = $base->query($sqlCountNewPublications);
    $rowCount = $resultCount->fetch(PDO::FETCH_ASSOC);
    $nuevas = $rowCount['nuevas'];

    $sqlDonaciones = "SELECT SUM(donaciones) AS total_donaciones FROM datos";
    $resultadoDonacion = $base->query($sqlDonaciones);
    $rowDonacion = $resultadoDonacion->fetch(PDO::FETCH_ASSOC);
    $totalDonaciones = $rowDonacion['total_donaciones'];

    $sqlUsuarios = "SELECT SUM(usuarios_activos) AS total_usuarios FROM datos";
    $resultadoUsuarios = $base->query($sqlUsuarios);
    $rowUsuarios = $resultadoUsuarios->fetch(PDO::FETCH_ASSOC);
    $totalUsuarios = $rowUsuarios['total_usuarios'];

    // Verificar si la cookie 'id_usuario' está definida y no está vacía
    if (isset($_COOKIE['id_usuario']) && !empty($_COOKIE['id_usuario'])) {
        $id_admi = $_COOKIE['id_usuario'];

        $sql = "SELECT * FROM admi WHERE Id_admi = ?";
        $resultado = $base->prepare($sql);
        $resultado->execute([$id_admi]);

        // Verificar si se encontraron resultados
        if ($resultado->rowCount() > 0) {
            $administrador = $resultado->fetch(PDO::FETCH_ASSOC);
            $contenido = $administrador['Foto'];
        } else {
            echo "No se encontró ningún administrador con ese ID.";
        }
    } else {
        // Redireccionar al usuario al inicio de sesión si la cookie no está definida
        header("Location: ../login_admi/index.php");
        exit; // Terminar la ejecución del script después de redireccionar
    }

    
    ?>

    <!-- SIDEBAR -->
   
    <section id="sidebar">
        <a href="#" class="brand">
            <i class='bx bxs-smile'></i>
            <span class="text">Pobres de Marimar</span>
        </a>
        <ul class="side-menu top">
            <li id="panel" class="active">
                <a href="panel.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Panel</span>
                </a>
            </li>
            <li id="blog">
                <a href="publicaciones.php">
                    <i class='bx bxs-book-content'></i>
                    <span class="text">Publicaciones</span>
                </a>
            </li>
            <li id="editors">
                <a href="editores.php">
                    <i class='bx bxs-group'></i>
                    <span class="text">Editores</span>
                </a>
            </li>
            <li id="users">
                <a href="usuarios.php">
                    <i class='bx bxs-user-circle'></i>
                    <span class="text">Usuarios</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="cerrar.sesion.php" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Cerrar sesión</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->

    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <form action="#" class="search-form">
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
                </form>
            <input type="checkbox" id="switch-mode" class="switch-input" hidden>
            <label for="switch-mode" class="switch-mode">
                <i class="bx bx-sun"></i>
                <i class="bx bx-moon"></i>
            </label>
            <a href="#" class="profile">
                <?php echo "<img src='data:image/jpeg;base64," . base64_encode($contenido) . "' alt='Foto de perfil'>" ?>
            </a>
        </nav>
        <!-- NAVBAR -->


        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Resumen</h1>
                </div>
            </div>

            <ul class="box-info">
                <li>
                    <i class='bx bxs-calendar-check'></i>
                    <span class="text">
                        <h3>
                            <?php echo $nuevas; ?>
                        </h3>
                        <p>Publicaciones Nuevas</p>
                    </span>
                </li>
                <li>
                    <i class='bx bxs-group'></i>
                    <span class="text">
                        <h3>
                            <?php echo $totalUsuarios ?>
                        </h3>
                        <p>Visitantes totales</p>
                    </span>
                </li>
                <li>
                    <i class='bx bxs-dollar-circle'></i>
                    <span class="text">
                        <h3>$
                            <?php echo $totalDonaciones ?>
                        </h3>
                        <p>Donaciones totales</p>
                    </span>
                </li>
            </ul>
            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Publicaciones por Aprobar</h3>
                        <i class='bx bx-search'></i>
                        <i class='bx bx-filter'></i>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Editor</th>
                                <th>Fecha</th>
                                <th>Estatus</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <img src="img/people.png">
                                    <p>John Doe</p>
                                </td>
                                <td>01-10-2021</td>
                                <td><span class="status completed">Completed</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="img/people.png">
                                    <p>John Doe</p>
                                </td>
                                <td>01-10-2021</td>
                                <td><span class="status pending">Pending</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="img/people.png">
                                    <p>John Doe</p>
                                </td>
                                <td>01-10-2021</td>
                                <td><span class="status process">Process</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="img/people.png">
                                    <p>John Doe</p>
                                </td>
                                <td>01-10-2021</td>
                                <td><span class="status pending">Pending</span></td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="img/people.png">
                                    <p>John Doe</p>
                                </td>
                                <td>01-10-2021</td>
                                <td><span class="status completed">Completed</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="todo">
                    <div class="head">
                    </div>
                    <?php
                    include ("mapa.php");
                    ?>
                </div>
            </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->

    <script src="script.js"></script>

</body>

</html>