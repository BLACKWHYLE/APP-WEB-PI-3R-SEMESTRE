<?php
// Verificar si la cookie no está presente
if (!isset ($_COOKIE['id_usuario'])) {
    header("Location: ../login_admi/index.php"); // Redireccionar al usuario al formulario de inicio de inicio de sesión
    exit; // Detener la ejecución del resto del código
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Enlace a la hoja de estilos de Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">


    <!-- Otros estilos -->
    <link
        href='https://fonts.googleapis.com/css2?family=Lato:wght@400;700&family=Poppins:wght@400;500;600;700&display=swap'
        rel='stylesheet'>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="style.css">


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

    <!-- Favicon -->
    <link rel="icon" href="mewing.jpg" type="image/x-icon">
    <title>Panel de administración</title>
</head>

<body>
    <?php
    require ("../Datos_conexion/conexion.php");
    // Verificar si la cookie 'id_usuario' está definida y no está vacía
    if (isset ($_COOKIE['id_usuario']) && !empty ($_COOKIE['id_usuario'])) {
        $id_admi = $_COOKIE['id_usuario'];

        $sql = "SELECT * FROM admi WHERE Id_admi = ?";
        $resultado = $base->prepare($sql);
        $resultado->execute([$id_admi]);

        // Verificar si se encontraron resultados
        if ($resultado->rowCount() > 0) {
            $administrador = $resultado->fetch(PDO::FETCH_ASSOC);
            $contenido = $administrador['Foto'];
        } else {
            echo "No se encontró ningún administrador con ese ID.";
        }
    } else {
        // Redireccionar al usuario al inicio de sesión si la cookie no está definida
        header("Location: ../login_admi/index.php");
        exit; // Terminar la ejecución del script después de redireccionar
    }

    if (isset ($_GET["pagina"])) {
        if ($_GET["pagina"] == 1) {
            header("Location:usuarios.php");
        } else {
            $pagina = $_GET["pagina"];
        }
    } else {
        $pagina = 1;
    }

    $sql_total = "SELECT * FROM usuarios";
    $resultado = $base->prepare($sql_total);
    $resultado->execute(array());

    $num_filas = $resultado->rowCount();

    $tamano_paginas = 5;

    $empezar_desde = ($pagina - 1) * $tamano_paginas;

    $total_paginas = ceil($num_filas / $tamano_paginas);

    $resultado->closeCursor();

    $sql_limite = "SELECT * FROM usuarios LIMIT $empezar_desde, $tamano_paginas";

    $resultado = $base->prepare($sql_limite);
    $resultado->execute();

    $registro = $base->query(
        "SELECT usuarios.*, YEAR(CURDATE()) - YEAR(Fecha_Nacimiento) AS Edad,
         DATE(usuarios_datos_registro.Fecha_registro) AS Fecha_registro
         FROM usuarios
         INNER JOIN usuarios_datos_registro
         ON usuarios.Id_usuario = usuarios_datos_registro.Id_usuario
         LIMIT $empezar_desde, $tamano_paginas"
    )->fetchAll(PDO::FETCH_OBJ); ?>

    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
            <i class='bx bxs-smile'></i>
            <span class="text">Equipo 4</span>
        </a>
        <ul class="side-menu top">
            <li id="panel">
                <a href="panel.php">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Panel</span>
                </a>
            </li>
            <li id="blog">
                <a href="publicaciones.php">
                    <i class='bx bxs-book-content'></i>
                    <span class="text">Publicaciones</span>
                </a>
            </li>
            <li id="analytics" class="active">
                <a href="analiticas.php">
                    <i class='bx bxs-doughnut-chart'></i>
                    <span class="text">Analíticas</span>
                </a>
            </li>
            <li id="messages">
                <a href="mensajes.php">
                    <i class='bx bxs-message-dots'></i>
                    <span class="text">Mensajes</span>
                </a>
            </li>
            <li id="editors">
                <a href="editores.php">
                    <i class='bx bxs-group'></i>
                    <span class="text">Editores</span>
                </a>
            </li>
            <li id="users">
                <a href="usuarios.php">
                    <i class='bx bxs-user-circle'></i>
                    <span class="text">Usuarios</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a href="#">
                    <i class='bx bxs-cog'></i>
                    <span class="text">Ajustes</span>
                </a>
            </li>
            <li>
                <a href="cerrar.sesion.php" class="logout">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Cerrar sesión</span>
                </a>
            </li>
        </ul>
    </section>
    <!-- SIDEBAR -->

    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>
            <form action="#" class="search-form">
            <a href="#" class="nav-link">Categories</a>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="switch-mode" class="switch-input" hidden>
            <label for="switch-mode" class="switch-mode">
                <i class="bx bx-sun"></i>
                <i class="bx bx-moon"></i>
            </label>
            <div class="notification-container">
                <a href="#" class="notification">
                    <i class="bx bxs-bell"></i>
                    <span class="num">8</span>
                </a>
                <div class="notification-dropdown"></div>
            </div>
            <a href="#" class="profile">
                <?php echo "<img src='data:image/jpeg;base64," . base64_encode($contenido) . "' alt='Foto de perfil del administrador'>" ?>
            </a>
        </nav>
        <!-- NAVBAR -->

        <!-- MAIN -->
        <main>
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/SITIO-EN-CONSTRUCCION.jpg/1199px-SITIO-EN-CONSTRUCCION.jpg"
                alt="Sitio web, en matenimiento">
        </main>

        <script src="script.js"></script>
        <!-- Importar jQuery -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <!-- Importar Popper.js -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <!-- Importar Bootstrap JS -->
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>

</html>