<?php
require("../Datos_conexion/conexion2.php");

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar los datos del formulario
    $id_publicacion = $_POST['id_publicacion_editar'];
    $titulo = $_POST['titulo'];
    $contenido = $_POST['contenido'];
    $estatus = $_POST['estatus'];
    $comentarios = $_POST['comentarios'];
    $pagina = $_POST['pagina'];

    // Verificar si se subió una nueva imagen
    if ($_FILES['foto']['size'] > 0) {
        $foto = addslashes(file_get_contents($_FILES['foto']['tmp_name']));
        // Actualizar la foto de la publicación en la base de datos
        $sql_update_foto = "UPDATE publicaciones SET Imagen='$foto' WHERE Id_publicacion=$id_publicacion";
        mysqli_query($conexion, $sql_update_foto);
    }

    // Actualizar los datos de la publicación en la tabla 'publicaciones'
    $sql_update_publicacion = "UPDATE publicaciones SET Titulo='$titulo', Contenido='$contenido' WHERE Id_publicacion=$id_publicacion";
    mysqli_query($conexion, $sql_update_publicacion);

    // Actualizar los datos de la publicación en la tabla 'publicaciones_datos'
    $sql_update_datos = "UPDATE publicaciones_datos SET Estatus='$estatus', Comentarios_estatus='$comentarios' WHERE Id_publicacion=$id_publicacion";

    if (mysqli_query($conexion, $sql_update_datos)) {
        header("Location: publicaciones.php?pagina=" . $pagina);
        exit; // Terminar el script después de redireccionar
    } else {
        echo "Error al actualizar los datos de la publicación: " . mysqli_error($conexion);
    }
}

// Cerrar conexión
mysqli_close($conexion);
?>
