<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="assets/images/favicon.ico">
<?php
	include 'Datos_conexion/conexion.php';
?>
<title>La pobreza en pandemia</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">
<link href="assets/css/theme.css" rel="stylesheet">
<!-- Begin tracking codes here, including ShareThis/Analytics -->
    
<!-- End tracking codes here, including ShareThis/Analytics -->
</head>
<body class="layout-page">

	<style>
		.footer-widget {
			margin-bottom: 1x; /* Ajusta el margen inferior de los elementos .footer-widget */
		}
		.footer-widget {
			margin-top: 1px; /* Ajusta el margen superior del footer */
		}
	</style>

<!-- Begin Menu Navigation
================================================== -->
<header class="navbar navbar-toggleable-md navbar-light bg-white fixed-top mediumnavigation">
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsWow" aria-controls="navbarsWow" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="container">
	<!-- Begin Logo -->
	<a class="navbar-brand" href="index.html">
	<img src="assets/images/logo.png" alt="Affiliates - Free Bootstrap Template">
	</a>
	<!-- End Logo -->
	<!-- Begin Menu -->
	<div class="collapse navbar-collapse" id="navbarsWow">
		<!-- Begin Menu -->
		<ul class="navbar-nav ml-auto">
			<li class="nav-item">
			<a class="nav-link" href="index.html">INICIO</a>
			</li>
            <li class="nav-item">
			<a class="nav-link" href="category.php">PUBLICACIONES</a>
			</li>
			<li class="nav-item">
			<a class="nav-link" href="about.html">ACERCA DE</a>
			</li>
			<li class="nav-item">
			<a class="nav-link" href="contact.html">CONTACTO</a>
			</li>
		</ul>
		<!-- End Menu -->
	</div>
</div>
</header>
<!-- End Menu Navigation
================================================== -->
<div class="site-content">
	<div class="container">
		<!-- Content
    ================================================== -->
		<div class="main-content">
			<!-- Begin Article
            ================================================== -->
			<div class="row">
				<!-- Sidebar -->
				<div class="col-sm-4">
					<div class="sidebar">
						<div class="sidebar-section">
							<h5><span>DATO INTERESTANTE</span></h5>
							<!-- Go to your Mailchimp account/Lists/Sign Up Forms/Embedded forms and replace the code below with your own  -->
                            <!-- Begin MailChimp Signup Form -->
                            <link href="https://cdn-images.mailchimp.com/embedcode/classic-10_7.css" rel="stylesheet" type="text/css">
                            <div id="mc_embed_signup">
                                <form action="https://wowthemes.us11.list-manage.com/subscribe/post?u=8aeb20a530e124561927d3bd8&amp;id=8c3d2d214b" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                                    <div id="mc_embed_signup_scroll">
                                        <h2>La pobreza extrema ha disminuido significativamente en las últimas décadas, pero aún afecta a más de 700 millones de personas en todo el mundo.</h2>
                                    </div>
                                </form>
                            </div>
                            <script type='text/javascript' src='https://s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js'></script>
                            <script type='text/javascript'>(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]='EMAIL';ftypes[0]='email';fnames[3]='MMERGE3';ftypes[3]='text';fnames[1]='MMERGE1';ftypes[1]='text';fnames[2]='MMERGE2';ftypes[2]='text';fnames[4]='MMERGE4';ftypes[4]='text';fnames[5]='MMERGE5';ftypes[5]='text';}(jQuery));var $mcj = jQuery.noConflict(true);</script>
                            <!--End mc_embed_signup-->
						</div>
						<div class="sidebar-section">
							<h5><span>UTIL PARA TI</span></h5>
							<ul>
								<li><a target="_blank" href="https://www.un.org/es/get-involved">Colabora con la ONU</a></li>
								<li><a target="blank" href="https://www.un.org/es/our-work#:~:text=Proteger%20los%20derechos%20humanos,Defender%20el%20derecho%20internacional">Desafios globales de la ONU</a></li>
								<li><a target="_blank" href="https://www.un.org/es/global-issues/water">El agua como factor de gran importancia</a></li>
							    <li><a target="_blank" href="https://www.un.org/es/global-issues/food">La importancia de la alimentacion</a></li>
							    <li><a target="_blank" href="https://www.un.org/es/global-issues/">Vision general</a></li>
							</ul>
						</div>
					</div>
				</div>
				<!-- Post -->
				<div class="col-sm-8">
					<div class="mainheading">
						<!-- Post Title -->
						<h1 class="posttitle">La pobreza en pandemia</h1>
					</div>
					<!-- Post Featured Image -->
					<img class="featured-image img-fluid" src="assets/images/1v2.jpg" alt="">
					<!-- End Featured Image -->
					<!-- Post Content -->
					<div class="article-post">
						<p>
							El mercado central de Djokoto, una aldea de la prefectura de Yoto, en el sur de Togo, es un lugar animado y bullicioso. Cada día atrae a cientos de personas que buscan comprar alimentos, ropa y artículos de cuidado personal. También es un lugar donde muchas personas, como Adjelé Noumekpo, de 41 años, se ganan la vida.
						</p>
						<p>
							Pero el mercado quedó en silencio a principios de 2020.
						</p>
						<blockquote>
							<p>
								“Cuando se desató la pandemia de COVID-19, quedamos encerrados en casa. La gente no podía venir al mercado a comprar nuestro aceite de palma”, dijo Noumekpo, madre de cuatro hijos, haciendo referencia a los confinamientos establecidos para frenar la propagación de la enfermedad.
							</p>
						</blockquote>
						<p>
							Los depósitos que había recibido a través de un programa de transferencias monetarias en los dos años anteriores la ayudaron a sobrevivir y sirvieron de protección financiera durante los difíciles tiempos que se avecinaban. El dinero le había servido para comprar algunos animales e iniciar una pequeña cooperativa, así como cantidades adicionales de semillas que le permitieron aumentar la producción familiar de aceite de cocina.
						</p>
                        <blockquote>
							<p>
								“Con mi familia estábamos en una situación tan difícil que, si no hubiéramos recibido esas transferencias de efectivo, habríamos tocado fondo. Nos habríamos terminado hundiendo”.
							</p>
						</blockquote>
						<p>
							La iniciativa que benefició a Noumekpo y a otras familias de Togo demuestra que la política fiscal —el uso del gasto público y los impuestos para influir en la economía— tiene un potencial considerable para proteger a los hogares contra las crisis y ayudarlos a comenzar a generar ingresos de nuevo. Sin embargo, de acuerdo con un nuevo estudio del Banco Mundial, las medidas fiscales pueden producir resultados diferentes según el lugar y la forma en que se apliquen.
						</p>
						<div class="clearfix">
						</div>
					</div>
					<!-- Post Date -->
					<p>
						<small>
						<span class="post-date"><time class="post-date" datetime="2018-01-12">12 Marzo 2024</time></span>
						</small>
					</p>
					<!-- Prev/Next -->
					<div class="row PageNavigation mt-4 prevnextlinks">
						<div class="col-md-6 rightborder pl-0">
							<a class="thepostlink" href="index.html">« INICIO</a>
						</div>
						<div class="col-md-6 text-right pr-0">
							<a class="thepostlink" href="pub2.html">NIÑOS EN POBREZA »</a>
						</div>
					</div><br>
					<!-- End Prev/Next -->

					
					<!-- Begin Comments
                    ================================================== -->
                    <div id="disqus_thread"></div>
<script>
    /**
    *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
    *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables    */
    /*
    var disqus_config = function () {
    this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
    this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
    };
    */
    (function() { // DON'T EDIT BELOW THIS LINE
    var d = document, s = d.createElement('script');
    s.src = 'https://blog-4sybp35byv.disqus.com/embed.js';
    s.setAttribute('data-timestamp', +new Date());
    (d.head || d.body).appendChild(s);
    })();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
                    <!--End Comments
                    ================================================== -->
				</div>
				<!-- End Post -->
			</div>
			<!-- End Article
            ================================================== -->
		</div>
	</div>
	<!-- /.container -->
<!-- Begin Footer
    ================================================== -->
	<footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="footer-widget">
                        <a href="contact.html">
                        <img src="assets/images/logo-foot.jpg" alt="logo footer" width="50%">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="footer-widget">
                        <h5 class="title">Recursos</h5>
                        <ul>
                            <li><a target="_blank" href="https://www.un.org/es/get-involved">Colabora con la ONU</a></li>
                            <li><a target="_blank" href="https://www.un.org/es/our-work#:~:text=Proteger%20los%20derechos%20humanos,Defender%20el%20derecho%20internacional">Desafios globales de la ONU</a></li>
                            <li><a target="_blank" href="https://www.un.org/es/global-issues/food">La importancia de la alimentacion</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="footer-widget">
                        <h5 class="title">Autor</h5>
                        <ul>
                            <li><a href="/about.html">Acerca de</a></li>
                            <li><a href="/contact.html">Contacto</a></li>
                            
                            
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="footer-widget">
                        <h5 class="title">Acciones Especiales</h5>
                        <ul>
    
							<li><a href="admin/index.php">Inicia sesion como administrador</a></li>

							<li><a href="login/login.php">Inicia sesion como editor</a></li>
                            
                        </ul>
                        
                    </div>
                </div>
            </div>
            <div class="copyright">
                <p class="pull-left">
                     Copyright © 2024 Proyecto Integrador UDC
                </p>
                <p class="pull-right">
                    <!-- Leave credit to author unless you own a commercial license: https://www.wowthemes.net/freebies-license/ -->
                    <a target="_blank" href="index.html">"Blog Web"</a> - Diseñado por Ingenieros de la UDC
                </p>
                <div class="clearfix">
                </div>
            </div>
        </div>
        </footer>
	<!-- End Footer
    ================================================== -->
    </div>
    <!-- JavaScript
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="assets/js/masonry.pkgd.min.js"></script>
    <script src="assets/js/theme.js"></script>
	<script id="dsq-count-scr" src="//blog-4sybp35byv.disqus.com/count.js" async></script>
    </body>
    </html>