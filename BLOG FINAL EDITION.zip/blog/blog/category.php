<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="assets/images/favicon.ico">
	<title>Silented Voices</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css"
		integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">
	<link href="assets/css/theme.css" rel="stylesheet">
	<!-- Begin tracking codes here, including ShareThis/Analytics -->

	<?php
	include 'Datos_conexion/conexion.php';

	// Consulta para obtener el número total de filas
	$query_total = "SELECT COUNT(*) as total_filas FROM publicaciones";
	$resultado_total = mysqli_query($conexion, $query_total);
	$total_filas = mysqli_fetch_assoc($resultado_total)['total_filas'];

	// Calcular la cantidad de páginas
	$tamano_paginas = 4;
	$total_paginas = ceil($total_filas / $tamano_paginas);

	// Obtener el número de página actual
	$pagina = isset($_GET['pagina']) ? $_GET['pagina'] : 1;

	// Calcular el punto de inicio para la consulta
	$empezar_desde = ($pagina - 1) * $tamano_paginas;

	// Consulta para obtener las publicaciones limitadas por página
	$query = "SELECT * FROM publicaciones LIMIT ?, ?";
	$statement = mysqli_prepare($conexion, $query);
	mysqli_stmt_bind_param($statement, 'ii', $empezar_desde, $tamano_paginas);
	mysqli_stmt_execute($statement);
	$resultado = mysqli_stmt_get_result($statement);
	?>

</head>

<body class="layout-default">

	<style>
		.footer-widget {
			margin-bottom: 1x;
			/* Ajusta el margen inferior de los elementos .footer-widget */
		}

		.footer-widget {
			margin-top: 1px;
			/* Ajusta el margen superior del footer */
		}
	</style>

	<!-- Begin Menu Navigation
================================================== -->
	<header class="navbar navbar-toggleable-md navbar-light bg-white fixed-top mediumnavigation">
		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
			data-target="#navbarsWow" aria-controls="navbarsWow" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="container">
			<!-- Begin Logo -->
			<a class="navbar-brand" href="index.html">
				<img src="assets/images/logo.png" alt="Affiliates - Free Bootstrap Template">
			</a>
			<!-- End Logo -->
			<!-- Begin Menu -->
			<div class="collapse navbar-collapse" id="navbarsWow">
				<!-- Begin Menu -->
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link" href="index.html">INICIO</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="category.php">PUBLICACIONES</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="about.html">ACERCA DE</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="contact.html">CONTACTO</a>
					</li>
				</ul>
				<!-- End Menu -->
			</div>
		</div>
	</header>
	<!-- End Menu Navigation
================================================== -->
	<div class="site-content">
		<div class="container">
			<div class="main-content">
				<!-- Category Archive
			================================================== -->

				<div class="section-title">
					<h2><span>TODAS LAS PUBLICACIONES</span></h2>
				</div>
				<div class="masonrygrid row listrecent">

					<?php
					// Verificar si la consulta tuvo éxito
					if ($resultado && mysqli_num_rows($resultado) > 0) {
						// Iterar sobre los resultados de la consulta
						while ($fila = mysqli_fetch_assoc($resultado)) {
							?>
							<!-- begin post -->
							<div class="col-md-6 grid-item">
								<div class="card">
									<a href="publi.php?publi=<?php echo $fila['Id_publicacion']; ?>">
										<img src='data:image/jpeg;base64,<?php echo base64_encode($fila['Imagen']); ?>'
											alt='Imagen de la publicación' width='350' height='1000'>
									</a>
									<div class="card-block">
										<h2 class="card-title"><a
												href="pub<?php echo $fila['Id_publicacion']; ?>.html"><?php echo $fila['Titulo']; ?></a>
										</h2>
										<h4 class="card-text"><?php echo $fila['Contenido']; ?></h4>
										<div class="metafooter">
											<div class="wrapfooter">
												<span class="post-read-more"><a
														href="pub<?php echo $fila['Id_publicacion']; ?>.html"
														title="Leer historia"><i class="fa fa-link"></i></a></span>
												<div class="clearfix"></div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-- end post -->
							<?php
						}
					} else {
						// Mostrar un mensaje si no hay resultados
						echo "<p>No se encontraron publicaciones.</p>";
					}


					?>
					<!-- end post -->
				</div>
				<!-- Pagination -->
				<div class="bottompagination">
					<div class="navigation">
						<nav class="pagination">
							<?php
							for ($i = 1; $i <= $total_paginas; $i++) {
								?>
								<a href="?pagina=<?php echo $i; ?>" <?php if ($i == $pagina)
									   echo 'class="active"'; ?>><?php echo $i; ?></a>
								<?php
							}
							?>
						</nav>
					</div>
				</div>
			</div>
		</div>
		</section>
	</div>
	</div>

	<!-- /.container -->

	<!-- Begin Footer
	================================================== -->
	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="footer-widget">
						<a href="contact.html">
							<img src="assets/images/logo-foot.jpg" alt="logo footer" width="50%">
						</a>
					</div>
				</div>
				<div class="col-sm-4">
					<div class="footer-widget">
						<h5 class="title">Recursos</h5>
						<ul>
							<li><a target="_blank" href="https://www.un.org/es/get-involved">Colabora con la ONU</a>
							</li>
							<li><a target="_blank"
									href="https://www.un.org/es/our-work#:~:text=Proteger%20los%20derechos%20humanos,Defender%20el%20derecho%20internacional">Desafios
									globales de la ONU</a></li>
							<li><a target="_blank" href="https://www.un.org/es/global-issues/food">La importancia de la
									alimentacion</a></li>
						</ul>
					</div>
				</div>
				<div class="col-sm-2">
					<div class="footer-widget">
						<h5 class="title">Autor</h5>
						<ul>
							<li><a href="/about.html">Acerca de</a></li>
							<li><a href="/contact.html">Contacto</a></li>


						</ul>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="footer-widget">
						<h5 class="title">Acciones Especiales</h5>
						<ul>

							<li><a href="admin/index.php">Inicia sesion como administrador</a></li>

							<li><a href="login/login.php">Inicia sesion como editor</a></li>

						</ul>

					</div>
				</div>
			</div>
			<div class="copyright">
				<p class="pull-left">
					Copyright © 2024 Proyecto Integrador UDC
				</p>
				<p class="pull-right">
					<!-- Leave credit to author unless you own a commercial license: https://www.wowthemes.net/freebies-license/ -->
					<a target="_blank" href="index.html">"Blog Web"</a> - Diseñado por Ingenieros de la UDC
				</p>
				<div class="clearfix">
				</div>
			</div>
		</div>
	</footer>
	<!-- End Footer
	================================================== -->
	</div>


	<!-- JavaScript
================================================== -->
	<script src="assets/js/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
		integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
		crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"
		integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn"
		crossorigin="anonymous"></script>
	<script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	<script src="assets/js/masonry.pkgd.min.js"></script>
	<script src="assets/js/theme.js"></script>
</body>

</html>