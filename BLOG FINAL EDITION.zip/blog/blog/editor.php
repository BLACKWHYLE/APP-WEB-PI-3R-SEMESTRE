<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="assets/images/favicon.ico">
<title>Silented Voices</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">
<link href="assets/css/theme.css" rel="stylesheet">
<!-- Begin tracking codes here, including ShareThis/Analytics -->
    
<!-- End tracking codes here, including ShareThis/Analytics -->
</head>
<body class="layout-default">

<style>
	.footer-widget {
        margin-bottom: 1x; /* Ajusta el margen inferior de los elementos .footer-widget */
    }
    .footer-widget {
        margin-top: 1px; /* Ajusta el margen superior del footer */
    }
</style>

<!-- Begin Menu Navigation
================================================== -->
<header class="navbar navbar-toggleable-md navbar-light bg-white fixed-top mediumnavigation">
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsWow" aria-controls="navbarsWow" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="container">
	<!-- Begin Logo -->
	<a class="navbar-brand" href="index.html">
	<img src="assets/images/logo.png" alt="Affiliates - Free Bootstrap Template">
	</a>
	<!-- End Logo -->
	<!-- Begin Menu -->
	<div class="collapse navbar-collapse" id="navbarsWow">
		<!-- Begin Menu -->
		<ul class="navbar-nav ml-auto">
			<li class="nav-item">
			<a class="nav-link" href="index.html">INICIO</a>
			</li>
            <li class="nav-item">
			<a class="nav-link" href="category.php">PUBLICACIONES</a>
			</li>
			<li class="nav-item">
			<a class="nav-link" href="about.html">ACERCA DE</a>
			</li>
			<li class="nav-item">
			<a class="nav-link" href="contact.html">CONTACTO</a>
			</li>
			<li class="nav-item">
			<a class="nav-link"  href="login/login.php">INICIA SESION</a>
			</li>
		</ul>
		<!-- End Menu -->
	</div>
</div>
</header>
<!-- End Menu Navigation
================================================== -->
<div class="site-content">
	<div class="container">
		<div class="main-content">		
			<!-- Category Archive
            ================================================== -->
			<section class="recent-posts row">
				<div class="col-sm-4">
					<div class="sidebar">
						<div class="sidebar-section">
							<h5><span>Publicar</span></h5>
							<!-- Go to your Mailchimp account/Lists/Sign Up Forms/Embedded forms and replace the code below with your own  -->
                            <!-- Begin MailChimp Signup Form -->
							<div class="article-post">
                                <form action="" method="post" enctype="multipart/form-data">
                                    <textarea rows="1" class="form-control mb-3" name="titulo" placeholder="Nombre del articulo"></textarea>
                                    <textarea rows="3" class="form-control mb-3" name="descripcion" placeholder="Descripción breve"></textarea>
                                    <textarea rows="8" class="form-control mb-3" name="contenido" placeholder="Contenido del articulo"></textarea>
                                    <input style="width: calc(100% - 0.2rem);" class="btn btn-img" type="file" accept="image/*" name="imagen">
                                    <br>    
                                    <br>
                                    <input class="btn btn-success" type="submit" value="Publicar">
                                </form>
                            </div>
                        </div>
					</div>
				</div>
			<div class="col-sm-8">
				<div class="section-title">
					<h2><span>TODAS LAS PUBLICACIONES</span></h2>
				</div>
				<div class="masonrygrid row listrecent">

				<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Conexión a la base de datos
        $base = new PDO('mysql:host=localhost; dbname=blog', 'root', '');
        $base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $base->exec("SET CHARACTER SET utf8");

        // Recuperar datos del formulario y validarlos
        $titulo = htmlspecialchars($_POST['titulo']);
        $descripcion = htmlspecialchars($_POST['descripcion']);
        $contenido = htmlspecialchars($_POST['contenido']);

        // Verificar si se ha subido una imagen y validarla
        if ($_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
            // Subir la imagen a ImgBB
            $imagen_data = file_get_contents($_FILES['imagen']['tmp_name']);
            $api_key = '65d33e628e2a8a950d7b083807b0dbfc'; // Reemplazar con tu API Key de ImgBB
            $response = uploadToImgBB($api_key, $imagen_data);

            // Verificar si la subida fue exitosa
            if ($response['success']) {
                $imagen_url = $response['data']['url'];

                // Preparar la consulta SQL para insertar los datos
                $consulta = $base->prepare("INSERT INTO publicaciones (Titulo, Brevedesc, Contenido, Imagen) VALUES (?, ?, ?, ?)");
                // Ejecutar la consulta
                $consulta->bindParam(1, $titulo);
                $consulta->bindParam(2, $descripcion);
                $consulta->bindParam(3, $contenido);
                $consulta->bindParam(4, $imagen_url);
                $consulta->execute();
            } else {
                throw new Exception("Error al subir la imagen a ImgBB: " . $response['error']['message']);
            }
        } else {
            throw new Exception("Hubo un error al subir la imagen.");
        }

        // Recuperar y mostrar las publicaciones
        $consulta = $base->query("SELECT * FROM publicaciones ORDER BY Id_publicacion DESC");

        while ($fila = $consulta->fetch(PDO::FETCH_ASSOC)) {
            echo '<div class="col-md-6 grid-item">';
			echo '<div class="card">';
			echo '<a href="ver_publicacion.php?id=' . $fila['Id_publicacion'] . '">';
			// Mostrar la imagen correctamente
			echo '<img class="img-fluid" src="' . $fila['Imagen'] . '" alt="' . $fila['Titulo'] . '">';
			echo '</a>';
			echo '<div class="card-block">';
			echo '<h2 class="card-title"><a href="ver_publicacion.php?id=' . $fila['Id_publicacion'] . '">' . $fila['Titulo'] . '</a></h2>';
			echo '<h4 class="card-text">' . $fila['Brevedesc'] . '</h4>';
			echo '</div>';
			echo '</div>';
			echo '</div>';
        }
    } catch (Exception $e) {
        // Manejar errores
        echo 'Error: ' . $e->getMessage();
    }
}

// Función para subir la imagen a ImgBB
function uploadToImgBB($api_key, $imagen_data) {
    $url = 'https://api.imgbb.com/1/upload?key=' . $api_key;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => array(
            'image' => base64_encode($imagen_data)
        ),
    ));
    $response = curl_exec($curl);
    $error = curl_error($curl);
    curl_close($curl);
    if ($error) {
        return array('success' => false, 'error' => $error);
    } else {
        return json_decode($response, true);
    }
}
?>



					
					<!-- begin post -->
					<div class="col-md-6 grid-item">
						<div class="card">
							<a href="pub3.html">
							<img class="img-fluid" src="assets/images/2.jpg" alt="Tree of Codes">
							</a>
							<div class="card-block">
								<h2 class="card-title"><a href="pub3.html">Ajuste en las líneas mundiales de pobreza</a></h2>
								<h4 class="card-text">La línea internacional de pobreza se establece como el umbral nacional de pobreza típico en los países más pobres del mundo.</h4>
								<div class="metafooter">
									<div class="wrapfooter">
										
										<span class="post-read-more"><a href="pub3.html" title="Read Story"><i class="fa fa-link"></i></a></span>
										<div class="clearfix">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- end post -->
					<!-- begin post -->
					<div class="col-md-6 grid-item">
						<div class="card">
							<a href="single.html">
							<img class="img-fluid" src="assets/images/3.jpg" alt="Red Riding Hood">
							</a>
							<div class="card-block">
								<h2 class="card-title"><a href="single.html">Pobreza Mundial</a></h2>
								<h4 class="card-text">Casi 700 millones de personas en todo el mundo viven en situación de pobreza extrema y subsisten con menos de USD 2,15 al día, esto es la línea de pobreza extrema.</h4>
								<div class="metafooter">
									<div class="wrapfooter">
										
										
										<span class="post-read-more"><a href="single.html" title="Read Story"><i class="fa fa-link"></i></a></span>
										<div class="clearfix">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- end post -->
					<!-- begin post -->
					<div class="col-md-6 grid-item">
						<div class="card">
							<a href="pub6.html">
							<img class="img-fluid" src="assets/images/5.jpg" alt="Is Intelligence Enough">
							</a>
							<div class="card-block">
								<h2 class="card-title"><a href="pub6.html">Pobreza y desigualdad</a></h2>
								<h4 class="card-text">analizar la pobreza desde una perspectiva de género permite entender una serie de procesos que están involucrados en el fenómeno, sus dinámicas y características en determinados contextos que explican que ciertos grupos de personas estén más expuestas a sufrir la pobreza. </h4>
								<div class="metafooter">
									<div class="wrapfooter">
										
										<span class="post-read-more"><a href="pub6.html" title="Read Story"><i class="fa fa-link"></i></a></span>
										<div class="clearfix">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- end post -->
					<!-- begin post -->
					<div class="col-md-6 grid-item">
						<div class="card">
							<a href="pub5.html">
							<img class="img-fluid" src="assets/images/6.jpg" alt="Markdown Example">
							</a>
							<div class="card-block">
								<h2 class="card-title"><a href="pub5.html">Lucha contra la pobreza</a></h2>
								<h4 class="card-text">La pandemia de COVID-19 marcó el fin de una era extraordinaria de avances en la reducción de la pobreza en el mundo. Entre 1990 y 2015, la tasa de pobreza extrema mundial se redujo más de la mitad, y más de 1000 millones de personas salieron de la pobreza.</h4>
								<div class="metafooter">
									<div class="wrapfooter">
										
										<span class="post-read-more"><a href="pub5.html" title="Read Story"><i class="fa fa-link"></i></a></span>
										<div class="clearfix">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- end post -->
				</div>
				<!-- Pagination -->
				<div class="bottompagination">
					<div class="navigation">
						<nav class="pagination">
							<a href="#" onclick="previousPage()">«</a>
							<a href="#" class="active" id="page1" onclick="changePage(1)">1</a>
							<a href="page2.html" id="page2" onclick="changePage(2)">2</a>
							<a href="#" id="page3" onclick="changePage(3)">3</a>
							<a href="#" id="page4" onclick="changePage(4)">4</a>
							<a href="#" id="page5" onclick="changePage(5)">5</a>
							<a href="#" onclick="nextPage()">»</a>
						</nav>
					</div>
				</div>
			</div>
			</div>
			</section>
		</div>
	</div>

	<script>
        let currentPage = 1;

        function changePage(pageNumber) {
            // Actualiza el número de página activa
            document.getElementById("page" + currentPage).classList.remove("active");
            document.getElementById("page" + pageNumber).classList.add("active");
            currentPage = pageNumber;
        }

        function previousPage() {
            if (currentPage > 1) {
                changePage(currentPage - 1);
            }
        }

        function nextPage() {
            if (currentPage < 5) { // Cambia 5 al número total de páginas
                changePage(currentPage + 1);
            }
        }
    </script>
	<!-- /.container -->
	
	<!-- Begin Footer
    ================================================== -->
	<footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="footer-widget">
                        <a href="contact.html">
                        <img src="assets/images/logo-foot.jpg" alt="logo footer" width="50%">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="footer-widget">
                        <h5 class="title">Recursos</h5>
                        <ul>
                            <li><a target="_blank" href="https://www.un.org/es/get-involved">Colabora con la ONU</a></li>
                            <li><a target="_blank" href="https://www.un.org/es/our-work#:~:text=Proteger%20los%20derechos%20humanos,Defender%20el%20derecho%20internacional">Desafios globales de la ONU</a></li>
                            <li><a target="_blank" href="https://www.un.org/es/global-issues/food">La importancia de la alimentacion</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="footer-widget">
                        <h5 class="title">Autor</h5>
                        <ul>
                            <li><a href="/about.html">Acerca de</a></li>
                            <li><a href="/contact.html">Contacto</a></li>
                            
                            
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="footer-widget">
                        <h5 class="title">Acciones Especiales</h5>
                        <ul>
    
							<li><a href="admin/index.php">Inicia sesion como administrador</a></li>

							<li><a href="/editor.html">Inicia sesion como editor</a></li>
                            
                        </ul>
                        
                    </div>
                </div>
            </div>
            <div class="copyright">
                <p class="pull-left">
                     Copyright © 2024 Proyecto Integrador UDC
                </p>
                <p class="pull-right">
                    <!-- Leave credit to author unless you own a commercial license: https://www.wowthemes.net/freebies-license/ -->
                    <a target="_blank" href="index.html">"Blog Web"</a> - Diseñado por Ingenieros de la UDC
                </p>
                <div class="clearfix">
                </div>
            </div>
        </div>
        </footer>
	<!-- End Footer
    ================================================== -->
</div>


<!-- JavaScript
================================================== -->
<script src="assets/js/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<script src="assets/js/ie10-viewport-bug-workaround.js"></script>
<script src="assets/js/masonry.pkgd.min.js"></script>
<script src="assets/js/theme.js"></script>
</body>
</html>