<!DOCTYPE html>
<html lang="es">

<head>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8866526132477486"
     crossorigin="anonymous"></script>
	<?php
	require 'Datos_conexion/conexion2.php';
	?>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="assets/images/favicon.ico">
	<title>Silented Voices</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css"
		integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">
	<link href="assets/css/theme.css" rel="stylesheet">
	<!-- Begin tracking codes here, including ShareThis/Analytics -->

	<!-- End tracking codes here, including ShareThis/Analytics -->
</head>

<body class="layout-default">

	<style>
		.footer-widget {
			margin-bottom: 1x;
			/* Ajusta el margen inferior de los elementos .footer-widget */
		}

		.footer-widget {
			margin-top: 1px;
			/* Ajusta el margen superior del footer */
		}
	</style>

	<!-- Begin Menu Navigation
================================================== -->
	<header class="navbar navbar-toggleable-md navbar-light bg-white fixed-top mediumnavigation">
		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
			data-target="#navbarsWow" aria-controls="navbarsWow" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="container">
			<!-- Begin Logo -->
			<a class="navbar-brand" href="index.html">
				<img src="assets/images/logo.png" alt="Affiliates - Free Bootstrap Template">
			</a>
			<!-- End Logo -->
			<!-- Begin Menu -->
			<div class="collapse navbar-collapse" id="navbarsWow">
				<!-- Begin Menu -->
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link" href="index.php">INICIO</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="category.php">PUBLICACIONES</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="about.html">ACERCA DE</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="contact.html">CONTACTO</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="./login/login.php">INICIAR SESION</a>
					</li>
				</ul>

				<!-- End Menu -->
			</div>
		</div>
	</header>
	<!-- End Menu Navigation
================================================== -->
	<div class="site-content">
		<!-- Home Jumbotron
	================================================== -->
		<section class="intro">
			<div class="wrapintro">
				<h1>SILENTED VOICES</h1>
				<h2 class="lead">Una pagina centrada en la imparticion de informacion acerca del problema mundial que
					representa la pobreza.<br>"La pobreza tiene muchas dimensiones, pero entre sus causas se encuentran
					el desempleo, la exclusión social y la alta vulnerabilidad de ciertas poblaciones ante desastres,
					enfermedades y otros fenómenos que les impiden ser productivas."</h2>
			</div>
		</section>
		<!-- Container
	================================================== -->
		<div class="container">
			<div class="main-content">
				<!-- Featured
			================================================== -->
				<section class="featured-posts">
					<div class="section-title">
						<h2><span>Nuevas Publicaciones</span></h2>
					</div>
					<div class="row listfeaturedtag">
						<?php
						// Consulta SQL para obtener los datos necesarios
						$sql = "SELECT publicaciones.Id_publicacion, publicaciones.Titulo, publicaciones.Breve_descripcion, publicaciones_datos.Fecha_publicacion, publicaciones.Imagen
								FROM publicaciones
					 			INNER JOIN publicaciones_datos ON publicaciones.Id_publicacion = publicaciones_datos.Id_publicacion
								WHERE publicaciones_datos.Fecha_publicacion >= DATE_SUB(CURDATE(), INTERVAL 3 DAY) AND publicaciones_datos.Estatus = 'Aprobada'
					 			LIMIT 0,2";
						$resultado = $conexion->query($sql);

						if ($resultado->num_rows > 0) {
							// Output data of each row
							while ($row = $resultado->fetch_assoc()) {
								?>
								<div class="col-sm-6">
									<div class="card">
										<div class="row">
											<div class="col-md-5 wrapthumbnail">
												<a href="ver_publicacion.php?id=<?php echo $row["Id_publicacion"] ?>">
													<img src="data:image/jpeg;base64,<?php echo base64_encode($row["Imagen"]); ?>"
														alt="<?php echo $row["Titulo"]; ?>">
												</a>
											</div>
											<div class="col-md-7">
												<div class="card-block">
													<h2 class="card-title"><a href="pub1.html"><?php echo $row["Titulo"]; ?></a>
													</h2>
													<h4 class="card-text"><?php echo $row["Breve_descripcion"]; ?></h4>
													<div class="metafooter">
														<div class="wrapfooter">
															<span class="post-read-more">
																<a href="ver_publicacion.php?id=<?php echo $row["Id_publicacion"]; ?>" title="Read Story">
																	<i class="fa fa-link"></i></a></span>
															<div class="clearfix"></div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<?php
							}
						} else {
							echo "0 results";
						}
						?>
						<!-- end post -->
					</div>
				</section>
				<!-- Posts Index
		================================================== -->
				<section class="recent-posts row">
					<div class="col-sm-4">
						<div class="sidebar">
							<div class="sidebar-section">
								<h5><span>DATO INTERESTANTE</span></h5>
								<!-- Go to your Mailchimp account/Lists/Sign Up Forms/Embedded forms and replace the code below with your own  -->
								<!-- Begin MailChimp Signup Form -->
								<link href="https://cdn-images.mailchimp.com/embedcode/classic-10_7.css"
									rel="stylesheet" type="text/css">
								<div id="mc_embed_signup">
									<form
										action="https://wowthemes.us11.list-manage.com/subscribe/post?u=8aeb20a530e124561927d3bd8&amp;id=8c3d2d214b"
										method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form"
										class="validate" target="_blank" novalidate>
										<div id="mc_embed_signup_scroll">
											<h2>La pobreza extrema ha disminuido significativamente en las últimas
												décadas,
												pero aún afecta a más de 700 millones de personas en todo el mundo.</h2>
										</div>
									</form>
								</div>
								<script type='text/javascript'
									src='https://s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js'></script>
								<script
									type='text/javascript'>(function ($) { window.fnames = new Array(); window.ftypes = new Array(); fnames[0] = 'EMAIL'; ftypes[0] = 'email'; fnames[3] = 'MMERGE3'; ftypes[3] = 'text'; fnames[1] = 'MMERGE1'; ftypes[1] = 'text'; fnames[2] = 'MMERGE2'; ftypes[2] = 'text'; fnames[4] = 'MMERGE4'; ftypes[4] = 'text'; fnames[5] = 'MMERGE5'; ftypes[5] = 'text'; }(jQuery)); var $mcj = jQuery.noConflict(true);</script>
								<!--End mc_embed_signup-->
							</div>
							<div class="sidebar-section">
								<h5><span>UTIL PARA TI</span></h5>
								<ul>
									<li><a target="_blank" href="https://www.un.org/es/get-involved">Colabora con la
											ONU</a>
									</li>
									<li><a target="blank"
											href="https://www.un.org/es/our-work#:~:text=Proteger%20los%20derechos%20humanos,Defender%20el%20derecho%20internacional">Desafios
											globales de la ONU</a></li>
									<li><a target="_blank" href="https://www.un.org/es/global-issues/water">El agua como
											factor de gran importancia</a></li>
									<li><a target="_blank" href="https://www.un.org/es/global-issues/food">La
											importancia de
											la alimentacion</a></li>
									<li><a target="_blank" href="https://www.un.org/es/global-issues/">Vision
											general</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-sm-8">
						<div class="section-title">
							<h2><span>Otras Publicaciones</span></h2>
						</div>
						<div class="masonrygrid row listrecent">
							<?php
							// Consulta SQL para obtener los datos necesarios
							$sql = "SELECT publicaciones.Id_publicacion, publicaciones.Titulo, publicaciones.Breve_descripcion, publicaciones.Imagen, publicaciones_datos.Fecha_publicacion
									FROM publicaciones
									INNER JOIN publicaciones_datos ON publicaciones.Id_publicacion = publicaciones_datos.Id_publicacion 
									WHERE publicaciones_datos.Fecha_publicacion >= DATE_SUB(CURDATE(), INTERVAL 3 DAY) AND publicaciones_datos.Estatus = 'Aprobada'
									LIMIT 0,6";

							$resultado = $conexion->query($sql);

							if ($resultado->num_rows > 0) {
								// Output data of each row
								while ($row = $resultado->fetch_assoc()) {
									?>
									<div class="col-md-6 grid-item">
										<div class="card">
											<a href="ver_publicacion.php?id=<?php echo $row["Id_publicacion"]; ?>">
												<img class="img-fluid"
													src="data:image/jpeg;base64,<?php echo base64_encode($row["Imagen"]); ?>"
													alt="<?php echo $row["Titulo"]; ?>">
											</a>
											<div class="card-block">
												<h2 class="card-title"><a
														href="pub<?php echo $row["Id_publicacion"]; ?>.html"><?php echo $row["Titulo"]; ?></a>
												</h2>
												<h4 class="card-text"><?php echo $row["Breve_descripcion"]; ?></h4>
												<div class="metafooter">
													<div class="wrapfooter">
														<span class="post-read-more">
														<a href="ver_publicacion.php?id=<?php echo $row["Id_publicacion"]; ?>"
																title="Read Story"><i class="fa fa-link"></i></a></span>
														<div class="clearfix"></div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<?php
								}
							} else {
								echo "0 results";
							}
							?>
						</div>
						<!-- Pagination -->
						<div class="bottompagination">
							<div class="navigation">
								<nav class="pagination">
									<span class="page-number"> &nbsp; &nbsp; Pagina 1 de 1 &nbsp; &nbsp; </span>
								</nav>
							</div>
						</div>
					</div>
				</section>
			</div>
		</div>
		<!-- /.container -->

		<!-- Begin Footer
	================================================== -->
		<footer class="footer">
			<div class="container">
				<div class="row">
					<div class="col-sm-3">
						<div class="footer-widget">
							<a href="contact.html">
								<img src="assets/images/logo-foot.jpg" alt="logo footer" width="50%">
							</a>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="footer-widget">
							<h5 class="title">Recursos</h5>
							<ul>
								<li><a target="_blank" href="https://www.un.org/es/get-involved">Colabora con la ONU</a>
								</li>
								<li><a target="_blank"
										href="https://www.un.org/es/our-work#:~:text=Proteger%20los%20derechos%20humanos,Defender%20el%20derecho%20internacional">Desafios
										globales de la ONU</a></li>
								<li><a target="_blank" href="https://www.un.org/es/global-issues/food">La importancia de
										la
										alimentacion</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="footer-widget">
							<h5 class="title">Autor</h5>
							<ul>
								<li><a href="/about.html">Acerca de</a></li>
								<li><a href="/contact.html">Contacto</a></li>


							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="footer-widget">
							<h5 class="title">Acciones Especiales</h5>
							<ul>

								<li><a href="admin/index.php">Inicia sesion como administrador</a></li>

								<li><a href="login/login.php">Inicia sesion como editor</a></li>

							</ul>

						</div>
					</div>
				</div>
				<div class="copyright">
					<p class="pull-left">
						Copyright © 2024 Proyecto Integrador UDC
					</p>
					<p class="pull-right">
						<!-- Leave credit to author unless you own a commercial license: https://www.wowthemes.net/freebies-license/ -->
						<a target="_blank" href="index.html">"Blog Web"</a> - Diseñado por Ingenieros de la UDC
					</p>
					<div class="clearfix">
					</div>
				</div>
			</div>
		</footer>
		<!-- End Footer
	================================================== -->
	</div>


	<!-- JavaScript
================================================== -->
	<script src="assets/js/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
		integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
		crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"
		integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn"
		crossorigin="anonymous"></script>
	<script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	<script src="assets/js/masonry.pkgd.min.js"></script>
	<script src="assets/js/theme.js"></script>
</body>

</html>