<?php
// Datos de conexión a la base de datos
$hostname = "localhost"; // Nombre del servidor de la base de datos
$username = "root"; // Nombre de usuario de la base de datos
$password = ""; // Contraseña de la base de datos
$database = "blog"; // Nombre de la base de datos

// Establecer la conexión
$conexion = mysqli_connect($hostname, $username, $password, $database);

// Verificar la conexión
if (!$conexion) {
    die("Error al conectar con la base de datos: " . mysqli_connect_error());
}

// Establecer el conjunto de caracteres
mysqli_set_charset($conexion, "utf8");
?>
