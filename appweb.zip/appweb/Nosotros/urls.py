from django.urls import path

from Nosotros import views

urlpatterns = [
    path('', views.nosotros, name="Nosotros"),
]