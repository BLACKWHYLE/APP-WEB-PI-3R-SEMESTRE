from django.apps import AppConfig


class NosotrosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Nosotros'
