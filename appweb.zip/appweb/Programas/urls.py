from django.urls import path

from Programas import views

urlpatterns = [
    path('', views.programas, name="Programas"),
]